document.addEventListener('DOMContentLoaded', () => {
    // 1. Navbar Scroll Effect (Manejo del fondo difuminado o sólido)
    const nav = document.querySelector('.header-wrapper');
    if (nav) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                nav.style.background = 'rgba(10, 10, 10, 0.95)';
                nav.style.borderBottom = '1px solid var(--color-accent)';
            } else {
                nav.style.background = 'rgba(10, 10, 10, 0.85)';
                nav.style.borderBottom = '1px solid var(--color-border-inner)';
            }
        });
    }

    // 2. Fullscreen Drawer Menu (Hamburger Menu)
    const hamburgerBtn = document.getElementById('nav-toggle');
    const fullscreenMenu = document.getElementById('fullscreen-menu');
    const menuLinks = fullscreenMenu ? fullscreenMenu.querySelectorAll('a') : [];
    let isMenuOpen = false;

    if (hamburgerBtn && fullscreenMenu) {
        hamburgerBtn.addEventListener('click', () => {
            isMenuOpen = !isMenuOpen;
            
            if (isMenuOpen) {
                hamburgerBtn.classList.add('is-active');
                gsap.to(fullscreenMenu, {
                    clipPath: 'circle(150% at calc(100% - 40px) 40px)',
                    duration: 1,
                    ease: 'power4.inOut'
                });
                if (menuLinks.length > 0) {
                    gsap.to(menuLinks, {
                        y: 0,
                        opacity: 1,
                        duration: 0.8,
                        stagger: 0.1,
                        delay: 0.3,
                        ease: 'power3.out'
                    });
                }
            } else {
                hamburgerBtn.classList.remove('is-active');
                gsap.to(fullscreenMenu, {
                    clipPath: 'circle(0% at calc(100% - 40px) 40px)',
                    duration: 0.8,
                    ease: 'power3.inOut'
                });
                if (menuLinks.length > 0) {
                    gsap.to(menuLinks, {
                        y: 50,
                        opacity: 0,
                        duration: 0.4,
                        ease: 'power2.in'
                    });
                }
            }
        });
    }

    // 3. GSAP Animations (Reveal Text)
    // Aparecen los elementos marcados con "reveal-text" a medida que entran en la pantalla
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        const revealElements = document.querySelectorAll('.reveal-text');
        
        revealElements.forEach((el) => {
            gsap.from(el, {
                scrollTrigger: {
                    trigger: el,
                    start: 'top 85%',
                },
                y: 50,
                opacity: 0,
                duration: 1,
                ease: 'power3.out'
            });
        });

        // Initialize GLightbox
        if (typeof GLightbox !== 'undefined') {
            const lightbox = GLightbox({
                selector: '.glightbox',
                touchNavigation: true,
                loop: true,
                zoomable: true
            });
        }
    }
});