<?php
/**
 * Template Name: Detalle de Espacio
 * Description: Plantilla para mostrar un espacio individual.
 */
get_header(); ?>

<main style="padding-top: 150px; padding-bottom: 7rem; min-height: 80vh;">
    <div class="container">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <div class="grid md:grid-cols-12 gap-12">
                <div class="md:col-span-7 reveal-text">
                    <div style="border-radius: 1.5rem; overflow: hidden; height: 600px; position: relative;">
                        <?php 
                        $gallery_ids = get_post_meta(get_the_ID(), '_casadepiedra_gallery_ids', true);
                        if (!empty($gallery_ids)) {
                            $ids_array = explode(',', $gallery_ids);
                            $carousel_items = array_merge($ids_array, $ids_array);
                            
                            echo '<div class="carousel-wrapper">';
                            echo '<div class="carousel-track">';
                            foreach ($carousel_items as $id) {
                                $img_url = wp_get_attachment_image_url($id, 'large');
                                $img_full = wp_get_attachment_image_url($id, 'full');
                                if ($img_url) {
                                    echo '<a href="'.esc_url($img_full).'" class="carousel-slide glightbox" data-gallery="espacio-gallery">';
                                    echo '<img src="'.esc_url($img_url).'" alt="Galería Espacio" loading="lazy" />';
                                    echo '</a>';
                                }
                            }
                            echo '</div>';
                            echo '</div>';
                        } else {
                            if(has_post_thumbnail()) { ?>
                                <a href="<?php the_post_thumbnail_url('full'); ?>" class="glightbox" data-gallery="espacio-gallery" style="display:block; height:100%;">
                                    <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover" style="cursor: zoom-in;" />
                                </a>
                            <?php } else { ?>
                                <div class="img-cover" style="background-color: var(--color-surface);"></div>
                            <?php } 
                        } ?>
                    </div>
                </div>
                
                <div class="md:col-span-5 reveal-text" style="display: flex; flex-direction: column; justify-content: center;">
                    <h1 class="text-h2" style="margin: 0 0 1.5rem 0; color: #fff;"><?php the_title(); ?></h1>
                    
                    <div class="text-body-lg" style="margin-bottom: 2.5rem;">
                        <?php the_content(); ?>
                    </div>
                    
                    <a href="<?php echo esc_url(home_url('/contacto')); ?>" style="align-self: flex-start; padding: 1rem 2.5rem; background: var(--color-accent); color: #000; border-radius: 9999px; text-decoration: none; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s; display: inline-block;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">Cotizar Espacio</a>
                </div>
            </div>
        <?php endwhile; endif; ?>
    </div>
</main>

<?php get_footer(); ?>
