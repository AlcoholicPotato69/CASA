<?php
/**
 * Casa de Piedra Luxury Theme - Functions
 */

// 1. Setup Theme
function casadepiedra_flush_rewrite() {
    if (!get_option('casadepiedra_rewrite_flushed')) {
        flush_rewrite_rules();
        update_option('casadepiedra_rewrite_flushed', true);
    }
}
add_action('admin_init', 'casadepiedra_flush_rewrite');

function casadepiedra_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ));
    register_nav_menus(array(
        'menu-principal' => 'Menú Principal Premium',
        'menu-footer' => 'Menú Footer'
    ));
}
add_action('after_setup_theme', 'casadepiedra_setup');

// 2. Enqueue Scripts & Styles
function casadepiedra_scripts() {
    // Estilos principales
    wp_enqueue_style('casadepiedra-style', get_stylesheet_uri(), array(), '3.5.0');
    
    // GSAP para animaciones
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), null, true);
    wp_enqueue_script('gsap-scrolltrigger', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap'), null, true);
    // JS Core and libraries
    wp_enqueue_script('imagesloaded');
    wp_enqueue_script('masonry');
    wp_enqueue_style('glightbox-css', 'https://cdn.jsdelivr.net/npm/glightbox/dist/css/glightbox.min.css', array(), '3.2.0');
    wp_enqueue_script('glightbox', 'https://cdn.jsdelivr.net/gh/mcstudios/glightbox/dist/js/glightbox.min.js', array(), '3.2.0', true);
    
    // Vanilla JS App
    wp_enqueue_script('casadepiedra-app', get_template_directory_uri() . '/assets/js/app.js', array('gsap', 'gsap-scrolltrigger', 'glightbox', 'masonry'), '3.5.0', true);
}
add_action('wp_enqueue_scripts', 'casadepiedra_scripts');

function casadepiedra_admin_scripts($hook) {
    // Load on post pages AND our new admin panel pages
    if (in_array($hook, array('post.php', 'post-new.php', 'toplevel_page_casa-panel', 'panel-casa_page_casa-panel-inicio', 'panel-casa_page_casa-panel-galeria'))) {
        wp_enqueue_media();
        wp_enqueue_script('casadepiedra-admin-gallery', get_template_directory_uri() . '/assets/js/admin-gallery.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'casadepiedra_admin_scripts');

// 3. Register Custom Post Types
function casadepiedra_register_cpts() {
    // CPT: Espacios
    register_post_type('espacios', array(
        'labels' => array(
            'name' => 'Espacios',
            'singular_name' => 'Espacio',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Espacio',
        ),
        'public' => true,
        'has_archive' => true,
        'show_in_menu' => 'casa-panel',
        'menu_icon' => 'dashicons-location-alt',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'espacios'),
    ));

    // CPT: Restaurantes
    register_post_type('restaurantes', array(
        'labels' => array(
            'name' => 'Restaurantes',
            'singular_name' => 'Restaurante',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Restaurante',
        ),
        'public' => true,
        'has_archive' => true,
        'show_in_menu' => 'casa-panel',
        'menu_icon' => 'dashicons-rest-api',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'restaurantes'),
    ));

    // CPT: Galería de Fotos
    register_post_type('galeria_fotos', array(
        'labels' => array(
            'name' => 'Fotos de Galería',
            'singular_name' => 'Foto',
            'add_new' => 'Añadir Nueva Foto',
            'add_new_item' => 'Añadir Nueva Foto a la Galería',
        ),
        'public' => true,
        'has_archive' => false,
        'show_in_menu' => 'casa-panel',
        'menu_icon' => 'dashicons-camera',
        'supports' => array('title', 'thumbnail'),
    ));

    // CPT: Eventos
    register_post_type('eventos', array(
        'labels' => array(
            'name' => 'Eventos',
            'singular_name' => 'Evento',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Evento',
        ),
        'public' => true,
        'has_archive' => true,
        'show_in_menu' => 'casa-panel',
        'menu_icon' => 'dashicons-calendar-alt',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'eventos'),
    ));
}
add_action('init', 'casadepiedra_register_cpts');

// 4. Meta Boxes para Restaurantes
function casadepiedra_add_restaurante_meta() {
    add_meta_box('casadepiedra_restaurante_info', 'Información del Restaurante', 'casadepiedra_restaurante_meta_callback', 'restaurantes', 'normal', 'high');
}
add_action('add_meta_boxes', 'casadepiedra_add_restaurante_meta');

function casadepiedra_restaurante_meta_callback($post) {
    wp_nonce_field('casadepiedra_save_restaurante_meta', 'casadepiedra_restaurante_meta_nonce');
    
    $menu_url = get_post_meta($post->ID, '_restaurante_menu', true);
    $telefono = get_post_meta($post->ID, '_restaurante_telefono', true);
    $horarios = get_post_meta($post->ID, '_restaurante_horario', true);
    $reserva_tipo = get_post_meta($post->ID, '_restaurante_reserva_tipo', true) ?: 'web';
    $reserva_valor = get_post_meta($post->ID, '_restaurante_reserva_valor', true);
    
    echo '<p><label for="restaurante_reserva_tipo"><strong>Tipo de Reserva:</strong></label><br/>';
    echo '<select id="restaurante_reserva_tipo" name="restaurante_reserva_tipo" style="width:100%;">';
    echo '<option value="web" ' . selected($reserva_tipo, 'web', false) . '>Sitio Web</option>';
    echo '<option value="tel" ' . selected($reserva_tipo, 'tel', false) . '>Llamada Telefónica</option>';
    echo '<option value="whatsapp" ' . selected($reserva_tipo, 'whatsapp', false) . '>WhatsApp</option>';
    echo '</select></p>';

    echo '<p><label for="restaurante_reserva_valor"><strong>Enlace, Teléfono o WhatsApp para Reservar:</strong></label><br/>';
    echo '<input type="text" id="restaurante_reserva_valor" name="restaurante_reserva_valor" value="' . esc_attr($reserva_valor) . '" style="width:100%;" placeholder="Ej: https://... o 4771234567" /></p><hr/>';

    echo '<p><label for="restaurante_menu"><strong>Enlace al Menú (URL o PDF):</strong></label><br/>';
    echo '<input type="url" id="restaurante_menu" name="restaurante_menu" value="' . esc_attr($menu_url) . '" style="width:100%;" /></p>';
    
    echo '<p><label for="restaurante_telefono"><strong>Teléfono de Contacto:</strong></label><br/>';
    echo '<input type="text" id="restaurante_telefono" name="restaurante_telefono" value="' . esc_attr($telefono) . '" style="width:100%;" /></p>';
    
    echo '<p><label for="restaurante_horario"><strong>Horarios:</strong></label><br/>';
    echo '<input type="text" id="restaurante_horario" name="restaurante_horario" value="' . esc_attr($horarios) . '" style="width:100%;" placeholder="Ej: Lunes a Domingo de 1pm a 11pm" /></p>';
}

function casadepiedra_save_restaurante_meta($post_id) {
    if (!isset($_POST['casadepiedra_restaurante_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_restaurante_meta_nonce'], 'casadepiedra_save_restaurante_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['restaurante_menu'])) {
        update_post_meta($post_id, '_restaurante_menu', esc_url_raw($_POST['restaurante_menu']));
    }
    if (isset($_POST['restaurante_telefono'])) {
        update_post_meta($post_id, '_restaurante_telefono', sanitize_text_field($_POST['restaurante_telefono']));
    }
    if (isset($_POST['restaurante_horario'])) {
        update_post_meta($post_id, '_restaurante_horario', sanitize_text_field($_POST['restaurante_horario']));
    }
    if (isset($_POST['restaurante_reserva_tipo'])) {
        update_post_meta($post_id, '_restaurante_reserva_tipo', sanitize_text_field($_POST['restaurante_reserva_tipo']));
    }
    if (isset($_POST['restaurante_reserva_valor'])) {
        update_post_meta($post_id, '_restaurante_reserva_valor', sanitize_text_field($_POST['restaurante_reserva_valor']));
    }
}
add_action('save_post_restaurantes', 'casadepiedra_save_restaurante_meta');

function casadepiedra_get_reserva_url($post_id) {
    $tipo = get_post_meta($post_id, '_restaurante_reserva_tipo', true);
    $valor = get_post_meta($post_id, '_restaurante_reserva_valor', true);
    
    if (empty($valor)) return esc_url(home_url('/contacto'));
    
    if ($tipo === 'tel') {
        return 'tel:' . preg_replace('/[^0-9+]/', '', $valor);
    } elseif ($tipo === 'whatsapp') {
        return 'https://wa.me/' . preg_replace('/[^0-9]/', '', $valor);
    } else {
        return esc_url($valor);
    }
}

// 5. Cargar Panel de Administración Global
require_once get_template_directory() . '/inc/admin-panel.php';

// 7. Meta Box para Galería (Restaurantes y Espacios)
function casadepiedra_add_gallery_meta() { 
    $screens = array('restaurantes', 'espacios');
    foreach ($screens as $screen) {
        add_meta_box('casadepiedra_gallery', 'Galería de Imágenes Múltiples', 'casadepiedra_gallery_callback', $screen, 'normal', 'high');
    }
}
add_action('add_meta_boxes', 'casadepiedra_add_gallery_meta');

function casadepiedra_gallery_callback($post) {
    wp_nonce_field('casadepiedra_save_gallery_meta', 'casadepiedra_gallery_meta_nonce');
    $gallery_ids = get_post_meta($post->ID, '_casadepiedra_gallery_ids', true);
    
    echo '<div style="margin-bottom:15px;">';
    echo '<input type="button" id="casadepiedra_upload_gallery_btn" class="button button-primary" value="Seleccionar Imágenes" /> ';
    echo '<input type="button" id="casadepiedra_clear_gallery_btn" class="button" value="Limpiar Galería" />';
    echo '</div>';
    
    echo '<input type="hidden" id="casadepiedra_gallery_ids" name="_casadepiedra_gallery_ids" value="' . esc_attr($gallery_ids) . '" />';
    
    echo '<div id="casadepiedra_gallery_preview" style="display:flex; flex-wrap:wrap; gap:10px;">';
    if (!empty($gallery_ids)) {
        $ids_array = explode(',', $gallery_ids);
        foreach ($ids_array as $id) {
            $img = wp_get_attachment_image_src($id, 'thumbnail');
            if ($img) {
                echo '<div style="display:inline-block; margin-right:10px; margin-bottom:10px; position:relative;"><img src="'.esc_url($img[0]).'" style="max-width:100px; height:auto; display:block;" /></div>';
            }
        }
    }
    echo '</div>';
}

function casadepiedra_save_gallery_meta($post_id) {
    if (!isset($_POST['casadepiedra_gallery_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_gallery_meta_nonce'], 'casadepiedra_save_gallery_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['_casadepiedra_gallery_ids'])) {
        update_post_meta($post_id, '_casadepiedra_gallery_ids', sanitize_text_field($_POST['_casadepiedra_gallery_ids']));
    }
}
add_action('save_post', 'casadepiedra_save_gallery_meta');

// 8. Meta Box para Espacios (Capacidad)
function casadepiedra_add_espacio_meta() {
    add_meta_box('casadepiedra_espacio_info', 'Información del Espacio', 'casadepiedra_espacio_meta_callback', 'espacios', 'normal', 'high');
}
add_action('add_meta_boxes', 'casadepiedra_add_espacio_meta');

function casadepiedra_espacio_meta_callback($post) {
    wp_nonce_field('casadepiedra_save_espacio_meta', 'casadepiedra_espacio_meta_nonce');
    $capacidad = get_post_meta($post->ID, '_espacio_capacidad', true);
    
    echo '<p><label for="espacio_capacidad"><strong>Capacidad de Personas:</strong></label><br/>';
    echo '<input type="text" id="espacio_capacidad" name="espacio_capacidad" value="' . esc_attr($capacidad) . '" style="width:100%;" placeholder="Ej: 1,000" /></p>';
    echo '<p class="description">Introduce solo el número o texto corto. Ejemplo: "1,000" (se mostrará como "Hasta 1,000 personas").</p>';
}

function casadepiedra_save_espacio_meta($post_id) {
    if (!isset($_POST['casadepiedra_espacio_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_espacio_meta_nonce'], 'casadepiedra_save_espacio_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['espacio_capacidad'])) {
        update_post_meta($post_id, '_espacio_capacidad', sanitize_text_field($_POST['espacio_capacidad']));
    }
}
add_action('save_post_espacios', 'casadepiedra_save_espacio_meta');

// 9. Meta Box para Eventos (Botón y Enlace)
function casadepiedra_add_evento_meta() {
    add_meta_box('casadepiedra_evento_info', 'Información del Evento', 'casadepiedra_evento_meta_callback', 'eventos', 'normal', 'high');
}
add_action('add_meta_boxes', 'casadepiedra_add_evento_meta');

function casadepiedra_evento_meta_callback($post) {
    wp_nonce_field('casadepiedra_save_evento_meta', 'casadepiedra_evento_meta_nonce');
    $btn_texto = get_post_meta($post->ID, '_evento_boton_texto', true) ?: 'Me interesa';
    $btn_enlace = get_post_meta($post->ID, '_evento_enlace', true);
    $expiracion = get_post_meta($post->ID, '_evento_expiracion', true);
    
    echo '<p><label for="evento_expiracion"><strong>Fecha y Hora de Vigencia (Baja Automática):</strong></label><br/>';
    echo '<input type="datetime-local" id="evento_expiracion" name="evento_expiracion" value="' . esc_attr($expiracion) . '" style="width:100%;" /></p>';
    echo '<p class="description">Pasada esta fecha y hora, el evento se ocultará automáticamente.</p><hr/>';

    echo '<p><label for="evento_boton_texto"><strong>Texto del Botón:</strong></label><br/>';
    echo '<input type="text" id="evento_boton_texto" name="evento_boton_texto" value="' . esc_attr($btn_texto) . '" style="width:100%;" placeholder="Ej: Me interesa" /></p>';
    
    echo '<p><label for="evento_enlace"><strong>Enlace Externo (Boletera / WhatsApp):</strong></label><br/>';
    echo '<input type="url" id="evento_enlace" name="evento_enlace" value="' . esc_attr($btn_enlace) . '" style="width:100%;" placeholder="https://" /></p>';
    echo '<p class="description">Este es el enlace al que irá el usuario al dar clic en la tarjeta.</p>';
}

function casadepiedra_save_evento_meta($post_id) {
    if (!isset($_POST['casadepiedra_evento_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_evento_meta_nonce'], 'casadepiedra_save_evento_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['evento_boton_texto'])) {
        update_post_meta($post_id, '_evento_boton_texto', sanitize_text_field($_POST['evento_boton_texto']));
    }
    if (isset($_POST['evento_enlace'])) {
        update_post_meta($post_id, '_evento_enlace', esc_url_raw($_POST['evento_enlace']));
    }
    if (isset($_POST['evento_expiracion'])) {
        update_post_meta($post_id, '_evento_expiracion', sanitize_text_field($_POST['evento_expiracion']));
    }
}
add_action('save_post_eventos', 'casadepiedra_save_evento_meta');

// 10. Sistema de Vigencia Automática para Eventos
if (!wp_next_scheduled('casadepiedra_daily_event_vigencia')) {
    // Programar para hoy a las 23:59 (hora de WP)
    $today_2359 = strtotime('today 23:59:00');
    if ($today_2359 < time()) {
        $today_2359 += DAY_IN_SECONDS;
    }
    wp_schedule_event($today_2359, 'daily', 'casadepiedra_daily_event_vigencia');
}

add_action('casadepiedra_daily_event_vigencia', 'casadepiedra_check_expired_events');
function casadepiedra_check_expired_events() {
    $current_datetime_wp = wp_date('Y-m-d\TH:i');
    
    $args = array(
        'post_type' => 'eventos',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key' => '_evento_expiracion',
                'value' => $current_datetime_wp,
                'compare' => '<',
                'type' => 'CHAR'
            ),
            array(
                'key' => '_evento_expiracion',
                'value' => '',
                'compare' => '!=',
            )
        )
    );

    $expired_events = new WP_Query($args);
    if ($expired_events->have_posts()) {
        foreach ($expired_events->posts as $evento) {
            $evento_data = array(
                'ID' => $evento->ID,
                'post_status' => 'draft'
            );
            wp_update_post($evento_data);
        }
    }
}

// 7. Cargar script de auto-poblado (Páginas, CPTs y Accesos Directos)
require_once get_template_directory() . '/inc/populate.php';

// Restaurar enlace de Eventos en el menú principal tras borrar la página
function casadepiedra_restore_eventos_menu_link() {
    // Solo purgar reglas de reescritura una vez para que el CPT /eventos/ no dé 404
    if (!get_option('casadepiedra_rewrites_flushed_eventos')) {
        flush_rewrite_rules();
        update_option('casadepiedra_rewrites_flushed_eventos', true);
    }

    $menu_name = 'Menú Principal Premium';
    $menu_exists = wp_get_nav_menu_object($menu_name);
    
    if ($menu_exists) {
        $items = wp_get_nav_menu_items($menu_exists->term_id);
        $has_eventos = false;
        
        // El link "Eventos" en el menú puede ser de tipo 'post_type' (página) o 'custom' (nuestro link).
        if ($items) {
            foreach ($items as $item) {
                if ($item->title === 'Eventos') {
                    $has_eventos = true;
                    // Si el usuario borró la página, el ítem del menú suele quedar huérfano y puede dar problemas.
                    // Si el objeto ya no existe, el title podría estar vacío, pero revisamos por si acaso.
                    break;
                }
            }
        }
        
        // Si no se encontró ningún ítem titulado "Eventos" válido, lo inyectamos.
        if (!$has_eventos) {
            wp_update_nav_menu_item($menu_exists->term_id, 0, array(
                'menu-item-title'  => 'Eventos',
                'menu-item-url'    => home_url('/eventos/'),
                'menu-item-status' => 'publish',
                'menu-item-type'   => 'custom',
            ));
        }
    }
}
add_action('init', 'casadepiedra_restore_eventos_menu_link', 99);

// Forzar que la URL /eventos/ SIEMPRE cargue la plantilla de tarjetas, 
// incluso si el usuario crea accidentalmente una Página estática llamada "Eventos".
function casadepiedra_force_eventos_template($template) {
    if (is_post_type_archive('eventos') || is_page('eventos')) {
        $archive_template = locate_template('archive-eventos.php');
        if ($archive_template) {
            return $archive_template;
        }
    }
    return $template;
}
add_filter('template_include', 'casadepiedra_force_eventos_template', 99);

// 9. Filtrado de Menú y Restricción de Secciones Desactivadas
function casa_filter_nav_menu_items($items, $args) {
    $nosotros_active = get_option('casa_opt_status_nosotros', '1') === '1';
    $espacios_active = get_option('casa_opt_status_espacios', '1') === '1';
    $restaurantes_active = get_option('casa_opt_status_restaurantes', '1') === '1';
    $galeria_active = get_option('casa_opt_status_galeria', '1') === '1';
    $eventos_active = get_option('casa_opt_status_eventos', '1') === '1';
    $contacto_active = get_option('casa_opt_status_contacto', '1') === '1';

    foreach ($items as $key => $item) {
        $url = $item->url;
        if (!$nosotros_active && (strpos($url, '/quienes-somos') !== false || strpos($url, '/nosotros') !== false)) {
            unset($items[$key]);
        }
        elseif (!$espacios_active && strpos($url, '/espacios') !== false) {
            unset($items[$key]);
        }
        elseif (!$restaurantes_active && strpos($url, '/restaurantes') !== false) {
            unset($items[$key]);
        }
        elseif (!$galeria_active && strpos($url, '/galeria') !== false) {
            unset($items[$key]);
        }
        elseif (!$eventos_active && strpos($url, '/eventos') !== false) {
            unset($items[$key]);
        }
        elseif (!$contacto_active && strpos($url, '/contacto') !== false) {
            unset($items[$key]);
        }
    }
    return $items;
}
add_filter('wp_nav_menu_objects', 'casa_filter_nav_menu_items', 10, 2);

function casa_restrict_deactivated_pages() {
    $nosotros_active = get_option('casa_opt_status_nosotros', '1') === '1';
    $espacios_active = get_option('casa_opt_status_espacios', '1') === '1';
    $restaurantes_active = get_option('casa_opt_status_restaurantes', '1') === '1';
    $galeria_active = get_option('casa_opt_status_galeria', '1') === '1';
    $eventos_active = get_option('casa_opt_status_eventos', '1') === '1';
    $contacto_active = get_option('casa_opt_status_contacto', '1') === '1';

    if (!$nosotros_active && (is_page('quienes-somos') || is_page('nosotros'))) {
        wp_redirect(home_url());
        exit;
    }
    if (!$espacios_active && (is_post_type_archive('espacios') || is_page('espacios') || is_singular('espacios'))) {
        wp_redirect(home_url());
        exit;
    }
    if (!$restaurantes_active && (is_post_type_archive('restaurantes') || is_page('restaurantes') || is_singular('restaurantes'))) {
        wp_redirect(home_url());
        exit;
    }
    if (!$galeria_active && is_page('galeria')) {
        wp_redirect(home_url());
        exit;
    }
    if (!$eventos_active && (is_post_type_archive('eventos') || is_page('eventos') || is_singular('eventos'))) {
        wp_redirect(home_url());
        exit;
    }
    if (!$contacto_active && is_page('contacto')) {
        wp_redirect(home_url());
        exit;
    }
}
add_action('template_redirect', 'casa_restrict_deactivated_pages');