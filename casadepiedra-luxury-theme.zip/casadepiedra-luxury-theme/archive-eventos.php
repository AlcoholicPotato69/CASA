<?php
/**
 * Template Name: Archivo de Eventos
 * Description: Plantilla para mostrar el grid de eventos públicos.
 */
get_header(); ?>

<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 6rem; min-height: 80vh;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center;">
            <span class="text-script" style="font-size: 3rem;"><?php echo esc_html(get_theme_mod('text_eventos_title', 'Próximos Eventos')); ?></span>
            <h2 class="text-h2" style="margin-top: 1rem;"><?php echo esc_html(get_theme_mod('text_eventos_desc', 'Experiencias a tu medida.')); ?></h2>
        </div>

        <?php
        $args = array(
            'post_type'      => 'eventos',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC'
        );
        $eventos_query = new WP_Query($args);

        if ($eventos_query->have_posts()) : ?>
            <div class="grid md:grid-cols-2 gap-12">
                <?php while ($eventos_query->have_posts()) : $eventos_query->the_post(); 
                    $btn_texto = get_post_meta(get_the_ID(), '_evento_boton_texto', true) ?: 'Me interesa';
                    $btn_enlace = get_post_meta(get_the_ID(), '_evento_enlace', true);
                    $link_url = !empty($btn_enlace) ? esc_url($btn_enlace) : '#';
                ?>
                    <div class="reveal-text">
                        <div class="luxury-card" style="height: 100%; display: flex; flex-direction: column;">
                            <a href="<?php the_permalink(); ?>" style="text-decoration: none; display: block;">
                                <div style="height: 300px; overflow: hidden; position: relative;">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover hover:scale-105 transition-transform duration-700" style="transition: transform 0.7s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';" />
                                    <?php else : ?>
                                        <div class="img-cover" style="background-color: var(--color-surface);"></div>
                                    <?php endif; ?>
                                </div>
                            </a>
                            <div style="padding: 2.5rem; flex-grow: 1; display: flex; flex-direction: column;">
                                <span class="text-caption">Próximamente</span>
                                <h3 class="text-h3" style="color: var(--color-text-primary); margin-top: 0.5rem; margin-bottom: 1rem;">
                                    <a href="<?php the_permalink(); ?>" style="text-decoration: none; color: inherit;"><?php the_title(); ?></a>
                                </h3>
                                <div class="text-body-lg" style="margin-bottom: 2rem; flex-grow: 1;">
                                    <?php echo wp_trim_words(get_the_excerpt() ?: get_the_content(), 20, '...'); ?>
                                </div>
                                
                                <div style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; border-top: 1px solid var(--color-border-inner); padding-top: 1.5rem; margin-top: auto;">
                                    <a href="<?php the_permalink(); ?>" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.2rem; border-bottom: 1px solid var(--color-border); padding-bottom: 4px; text-decoration: none;">
                                        Ver detalles
                                    </a>
                                    
                                    <a href="<?php echo $link_url; ?>" <?php if(!empty($btn_enlace)) echo 'target="_blank" rel="noopener noreferrer"'; ?> style="color: #000; background: var(--color-accent); padding: 0.5rem 1rem; border-radius: 4px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                                        <?php echo esc_html($btn_texto); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        <?php else : ?>
            <div style="text-align: center; padding: 6rem 0;">
                <span class="text-script" style="font-size: 3rem; color: var(--color-accent); display: block; margin-bottom: 1rem;">Estamos creando nuevas experiencias para ti</span>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
