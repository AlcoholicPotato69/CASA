<?php
/**
 * Template Name: Galería
 * Description: Plantilla predeterminada para la Galería.
 */
get_header(); ?>

<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 6rem;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center;">
            <span class="text-script" style="font-size: 3rem;">Galería</span>
            <h2 class="text-h2" style="margin-top: 1rem;">Momentos inolvidables.</h2>
        </div>

        <?php 
        if (have_posts()) {
            while (have_posts()) {
                the_post();
                $content = get_the_content();
                
                // Mostrar siempre el grid de galería si el contenido es solo el texto por defecto o está vacío.
                if (empty($content) || trim(strip_tags($content)) === 'Galería de imágenes.') {
                    ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem;">
                        <?php
                        $galeria_query = new WP_Query(array(
                            'post_type' => 'galeria_fotos',
                            'posts_per_page' => -1,
                            'post_status' => 'publish'
                        ));
                        
                        if ($galeria_query->have_posts()) {
                            // User uploaded images via CPT
                            while ($galeria_query->have_posts()) {
                                $galeria_query->the_post();
                                if (has_post_thumbnail()) {
                                    $img_thumb = get_the_post_thumbnail_url(get_the_ID(), 'large');
                                    $img_full = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    ?>
                                    <a href="<?php echo esc_url($img_full); ?>" class="reveal-text luxury-card glightbox" data-gallery="main-gallery" style="height: 300px; overflow: hidden; display: block; cursor: zoom-in;">
                                        <img src="<?php echo esc_url($img_thumb); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover" style="transition: transform 0.5s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';" loading="lazy" />
                                    </a>
                                    <?php
                                }
                            }
                            wp_reset_postdata();
                        } else {
                            // Demo Array Fallback
                            $images = [
                                "/images/salon_principal_1779523069698.png",
                                "/images/terraza_mezquite_1779523084857.png",
                                "/images/salon_pavorreales_1779523097528.png",
                                "/images/jardin_principal_1779523113451.png",
                                "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=2069&auto=format&fit=crop",
                                "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=2098&auto=format&fit=crop"
                            ];
                            
                            foreach ($images as $idx => $src) {
                                if (strpos($src, 'http') === 0) {
                                    $img_src = $src;
                                } else {
                                    $img_src = get_template_directory_uri() . '/assets' . $src;
                                }
                                ?>
                                <a href="<?php echo esc_url($img_src); ?>" class="reveal-text luxury-card glightbox" data-gallery="main-gallery" style="height: 300px; overflow: hidden; display: block; cursor: zoom-in;">
                                    <img src="<?php echo esc_url($img_src); ?>" alt="Gallery Image" class="img-cover" style="transition: transform 0.5s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';" loading="lazy" />
                                </a>
                                <?php
                            }
                        }
                        ?>
                    </div>
                    <?php
                } else {
                    // Si el usuario añadió su propia galería con Elementor o WP, se muestra aquí
                    the_content();
                }
            }
        }
        ?>
    </div>
</div>

<?php get_footer(); ?>
