<?php
/**
 * Template Name: Detalle de Restaurante
 * Description: Plantilla para mostrar un restaurante individual.
 */
get_header(); ?>

<main style="padding-top: 150px; padding-bottom: 7rem; min-height: 80vh;">
    <div class="container">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); 
            $menu_url = get_post_meta(get_the_ID(), '_restaurante_menu', true);
            $telefono = get_post_meta(get_the_ID(), '_restaurante_telefono', true);
            $horarios = get_post_meta(get_the_ID(), '_restaurante_horario', true);
        ?>
            <div class="grid md:grid-cols-12 gap-12">
                <div class="md:col-span-7 reveal-text">
                    <div style="border-radius: 1.5rem; overflow: hidden; height: 600px; position: relative;">
                        <?php 
                        $gallery_ids = get_post_meta(get_the_ID(), '_casadepiedra_gallery_ids', true);
                        if (!empty($gallery_ids)) {
                            $ids_array = explode(',', $gallery_ids);
                            // Duplicamos el array para el efecto de scroll infinito continuo
                            $carousel_items = array_merge($ids_array, $ids_array);
                            
                            echo '<div class="carousel-wrapper">';
                            echo '<div class="carousel-track">';
                            foreach ($carousel_items as $id) {
                                $img_url = wp_get_attachment_image_url($id, 'large');
                                $img_full = wp_get_attachment_image_url($id, 'full');
                                if ($img_url) {
                                    // Agregamos clase glightbox para el visor
                                    echo '<a href="'.esc_url($img_full).'" class="carousel-slide glightbox" data-gallery="restaurante-gallery">';
                                    echo '<img src="'.esc_url($img_url).'" alt="Galería Restaurante" loading="lazy" />';
                                    echo '</a>';
                                }
                            }
                            echo '</div>';
                            echo '</div>';
                        } else {
                            // Fallback a imagen destacada
                            if(has_post_thumbnail()) { ?>
                                <a href="<?php the_post_thumbnail_url('full'); ?>" class="glightbox" data-gallery="restaurante-gallery" style="display:block; height:100%;">
                                    <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover" style="cursor: zoom-in;" />
                                </a>
                            <?php } else { ?>
                                <div class="img-cover" style="background-color: var(--color-surface);"></div>
                            <?php } 
                        } ?>
                    </div>
                </div>
                
                <div class="md:col-span-5 reveal-text" style="display: flex; flex-direction: column; justify-content: center;">
                    <h1 class="text-h2" style="margin: 0 0 1.5rem 0; color: #fff;"><?php the_title(); ?></h1>
                    
                    <div class="text-body-lg" style="margin-bottom: 2rem;">
                        <?php the_content(); ?>
                    </div>

                    <div style="background: var(--color-surface); border: 1px solid var(--color-border-inner); border-radius: var(--radius-lg); padding: 2rem; margin-bottom: 2rem;">
                        <h3 style="color: var(--color-accent); font-size: 1.2rem; margin-bottom: 1.5rem; font-family: var(--font-heading);">Información</h3>
                        
                        <?php if ($horarios) : ?>
                            <div style="display: flex; gap: 1rem; margin-bottom: 1rem; color: var(--color-text-secondary);">
                                <span style="color: var(--color-accent);">🕒</span>
                                <span><?php echo esc_html($horarios); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($telefono) : ?>
                            <div style="display: flex; gap: 1rem; margin-bottom: 1rem; color: var(--color-text-secondary);">
                                <span style="color: var(--color-accent);">📞</span>
                                <span><?php echo esc_html($telefono); ?></span>
                            </div>
                        <?php endif; ?>

                        <?php if ($menu_url) : ?>
                            <div style="margin-top: 1.5rem;">
                                <a href="<?php echo esc_url($menu_url); ?>" target="_blank" style="display: inline-block; padding: 0.8rem 2rem; background: transparent; border: 1px solid var(--color-accent); color: var(--color-accent); border-radius: var(--radius-pill); text-decoration: none; font-weight: 600; font-family: var(--font-body); transition: all 0.3s;" onmouseover="this.style.background='var(--color-accent)'; this.style.color='#000';" onmouseout="this.style.background='transparent'; this.style.color='var(--color-accent)';">
                                    Ver Menú
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <a href="<?php echo esc_url(home_url('/contacto')); ?>" style="align-self: flex-start; padding: 1rem 2.5rem; background: var(--color-accent); color: #000; border-radius: 9999px; text-decoration: none; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s; display: inline-block;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">Reservar Ahora</a>
                </div>
            </div>
        <?php endwhile; endif; ?>
    </div>
</main>

<?php get_footer(); ?>
