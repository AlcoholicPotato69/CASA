<?php
/**
 * Template Name: Archivo de Restaurantes
 * Description: Plantilla para mostrar el grid de restaurantes.
 */
get_header(); ?>

<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 6rem;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center;">
            <span class="text-script" style="font-size: 3rem;"><?php echo esc_html(get_theme_mod('text_restaurantes_title', 'Gastronomía')); ?></span>
            <h2 class="text-h2" style="margin-top: 1rem;">Restaurantes de Autor.</h2>
            <p class="text-body-lg" style="max-width: 600px; margin: 1rem auto;">
                <?php echo esc_html(get_theme_mod('text_restaurantes_desc', 'Dentro del complejo Casa de Piedra, disfruta de propuestas gastronómicas exclusivas para deleitar tus sentidos.')); ?>
            </p>
        </div>

        <div class="grid md:grid-cols-2 gap-12">
            <?php
            $args = array(
                'post_type'      => 'restaurantes',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC'
            );
            $restaurantes_query = new WP_Query($args);

            if ($restaurantes_query->have_posts()) :
                while ($restaurantes_query->have_posts()) : $restaurantes_query->the_post(); 
                    $menu_url = get_post_meta(get_the_ID(), '_restaurante_menu', true);
                    $telefono = get_post_meta(get_the_ID(), '_restaurante_telefono', true);
                ?>
                    <div class="reveal-text">
                        <div class="luxury-card" style="height: 100%; display: flex; flex-direction: column;">
                            <a href="<?php the_permalink(); ?>" style="text-decoration: none; display: block;">
                                <div style="height: 300px; overflow: hidden; position: relative;">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover hover:scale-105 transition-transform duration-700" style="transition: transform 0.7s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';" />
                                    <?php else : ?>
                                        <div class="img-cover" style="background-color: var(--color-surface);"></div>
                                    <?php endif; ?>
                                </div>
                            </a>
                            <div style="padding: 2.5rem; flex-grow: 1; display: flex; flex-direction: column;">
                                <span class="text-caption">Especialidad</span>
                                <h3 class="text-h3" style="color: var(--color-text-primary); margin-top: 0.5rem; margin-bottom: 1rem;">
                                    <a href="<?php the_permalink(); ?>" style="text-decoration: none; color: inherit;"><?php the_title(); ?></a>
                                </h3>
                                <div class="text-body-lg" style="margin-bottom: 2rem; flex-grow: 1;">
                                    <?php the_excerpt(); ?>
                                </div>
                                
                                <div style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; border-top: 1px solid var(--color-border-inner); padding-top: 1.5rem;">
                                    <a href="<?php the_permalink(); ?>" style="color: var(--color-accent); font-family: var(--font-heading); font-size: 1.2rem; border-bottom: 1px solid var(--color-border); padding-bottom: 4px; text-decoration: none;">
                                        Ver detalles
                                    </a>
                                    
                                    <?php if ($menu_url) : ?>
                                        <a href="<?php echo esc_url($menu_url); ?>" target="_blank" style="color: #fff; background: var(--color-surface); border: 1px solid var(--color-border); padding: 0.5rem 1rem; border-radius: 4px; font-size: 0.9rem; text-decoration: none; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)';" onmouseout="this.style.background='var(--color-surface)';">
                                            Ver Menú
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo esc_url(home_url('/contacto')); ?>" style="color: #000; background: var(--color-accent); padding: 0.5rem 1rem; border-radius: 4px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                                        Reservar
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile;
                wp_reset_postdata();
            else : ?>
                <p style="text-align: center; grid-column: 1 / -1; color: var(--color-text-secondary);">Próximamente nuevos restaurantes.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>
