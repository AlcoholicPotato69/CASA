jQuery(document).ready(function($){
    var meta_image_frame;

    $('#casadepiedra_upload_gallery_btn').on('click', function(e){
        e.preventDefault();
        
        if (meta_image_frame) {
            meta_image_frame.open();
            return;
        }
        
        meta_image_frame = wp.media.frames.file_frame = wp.media({
            title: 'Seleccionar Imágenes para la Galería',
            button: { text: 'Usar estas imágenes' },
            multiple: 'add'
        });

        meta_image_frame.on('select', function(){
            var selection = meta_image_frame.state().get('selection');
            var ids = [];
            var html = '';
            
            selection.map(function(attachment){
                attachment = attachment.toJSON();
                ids.push(attachment.id);
                var url = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
                html += '<div style="display:inline-block; margin-right:10px; margin-bottom:10px; position:relative;">';
                html += '<img src="'+url+'" style="max-width:100px; height:auto; display:block;" />';
                html += '</div>';
            });
            
            $('#casadepiedra_gallery_ids').val(ids.join(','));
            $('#casadepiedra_gallery_preview').html(html);
        });

        meta_image_frame.open();
    });

    $('#casadepiedra_clear_gallery_btn').on('click', function(e){
        e.preventDefault();
        $('#casadepiedra_gallery_ids').val('');
        $('#casadepiedra_gallery_preview').html('');
    });
});
