<?php
/**
 * Script para auto-poblar los datos originales de la plantilla,
 * crear menús y accesos directos de forma automática (Plug & Play).
 */

function casadepiedra_plug_and_play_setup() {
    $log_file = get_template_directory() . '/debug.log';
    file_put_contents($log_file, "Running setup...\n", FILE_APPEND);

    // Solo ejecutar una vez
    if (get_option('casadepiedra_fully_populated_v4')) {
        return;
    }
    file_put_contents($log_file, "Option v4 not found, proceeding...\n", FILE_APPEND);

    // 1. Crear Páginas
    $pages = array(
        'Inicio' => 'Página principal de Casa de Piedra.',
        'Quiénes Somos' => 'Nuestra historia.',
        'Espacios' => 'Nuestros espacios.',
        'Restaurantes' => 'Nuestros restaurantes.',
        'Galería' => 'Galería de imágenes.',
        'Contacto' => 'Contacto.'
    );

    $page_ids = array();

    foreach ($pages as $title => $content) {
        $page_check = get_page_by_title($title);
        if (!isset($page_check->ID)) {
            $page_id = wp_insert_post(array(
                'post_title'    => $title,
                'post_content'  => $content,
                'post_status'   => 'publish',
                'post_type'     => 'page'
            ));
            file_put_contents($log_file, "Inserted page $title with ID $page_id\n", FILE_APPEND);
        } else {
            $page_id = $page_check->ID;
            file_put_contents($log_file, "Found existing page $title with ID $page_id\n", FILE_APPEND);
        }
        
        $page_ids[$title] = $page_id;
        update_option('casadepiedra_page_id_' . sanitize_title($title), $page_id);
        
        if ($title === 'Inicio') {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $page_id);
            file_put_contents($log_file, "Set Inicio as front page\n", FILE_APPEND);
        }
    }

    // 2. Crear Menú Principal
    $menu_name = 'Menú Principal Premium';
    $menu_location = 'menu-principal';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);
        file_put_contents($log_file, "Created menu with ID $menu_id\n", FILE_APPEND);

        // Añadir elementos al menú en orden
        $menu_items = array('Inicio', 'Quiénes Somos', 'Espacios', 'Restaurantes', 'Galería', 'Contacto');
        foreach ($menu_items as $item_title) {
            if (isset($page_ids[$item_title])) {
                wp_update_nav_menu_item($menu_id, 0, array(
                    'menu-item-title' => $item_title,
                    'menu-item-object-id' => $page_ids[$item_title],
                    'menu-item-object' => 'page',
                    'menu-item-status' => 'publish',
                    'menu-item-type' => 'post_type',
                ));
            }
        }

        // Asignar el menú a la ubicación del tema
        $locations = get_theme_mod('nav_menu_locations');
        if (!is_array($locations)) {
            $locations = array();
        }
        $locations[$menu_location] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }

    // 3. Crear Restaurantes y Espacios Originales
    $restaurantes = array(
        array('title' => 'Corazón de Alcachofa', 'desc' => 'Una experiencia culinaria inigualable.'),
        array('title' => 'Agaves Casa de Piedra', 'desc' => 'Platillos mexicanos de autor.')
    );
    foreach ($restaurantes as $rest) {
        if (!get_page_by_title($rest['title'], OBJECT, 'restaurantes')) {
            wp_insert_post(array('post_title' => $rest['title'], 'post_content' => $rest['desc'], 'post_status' => 'publish', 'post_type' => 'restaurantes'));
        }
    }

    $espacios = array(
        array('title' => 'Salón Principal', 'desc' => 'Capacidad: 1,000 personas.'),
        array('title' => 'Terraza del Mezquite', 'desc' => 'Capacidad: 200 personas.'),
        array('title' => 'Salón Pavorreales', 'desc' => 'Capacidad: 100 personas.'),
        array('title' => 'Jardín Principal', 'desc' => 'Capacidad: 2,000 personas.')
    );
    foreach ($espacios as $esp) {
        if (!get_page_by_title($esp['title'], OBJECT, 'espacios')) {
            wp_insert_post(array('post_title' => $esp['title'], 'post_content' => $esp['desc'], 'post_status' => 'publish', 'post_type' => 'espacios'));
        }
    }

    update_option('casadepiedra_fully_populated_v4', true);
    file_put_contents($log_file, "Finished setup successfully.\n", FILE_APPEND);
}
add_action('init', 'casadepiedra_plug_and_play_setup');


// Crear Accesos Directos en la Barra Lateral Izquierda para las Páginas
function casadepiedra_custom_admin_menu_shortcuts() {
    $pages_to_shortcut = array(
        'Inicio' => 'dashicons-admin-home',
        'Quiénes Somos' => 'dashicons-groups',
        'Contacto' => 'dashicons-email-alt'
    );

    foreach ($pages_to_shortcut as $title => $icon) {
        $page = get_page_by_title($title);
        if ($page) {
            add_menu_page($title, $title, 'edit_pages', 'post.php?post=' . $page->ID . '&action=edit', '', $icon, 25);
        }
    }
}
add_action('admin_menu', 'casadepiedra_custom_admin_menu_shortcuts');
