<?php
/**
 * Casa de Piedra Luxury Theme - Functions
 */

// 1. Setup Theme
function casadepiedra_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ));
    register_nav_menus(array(
        'menu-principal' => 'Menú Principal Premium',
        'menu-footer' => 'Menú Footer'
    ));
}
add_action('after_setup_theme', 'casadepiedra_setup');

// 2. Enqueue Scripts & Styles
function casadepiedra_scripts() {
    // Estilos principales
    wp_enqueue_style('casadepiedra-style', get_stylesheet_uri(), array(), '3.5.0');
    
    // GSAP para animaciones
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), null, true);
    wp_enqueue_script('gsap-scrolltrigger', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap'), null, true);
    // GLightbox (Visor)
    wp_enqueue_style('glightbox-css', 'https://cdn.jsdelivr.net/npm/glightbox/dist/css/glightbox.min.css', array(), '3.2.0');
    wp_enqueue_script('glightbox', 'https://cdn.jsdelivr.net/gh/mcstudios/glightbox/dist/js/glightbox.min.js', array(), '3.2.0', true);
    
    // Vanilla JS App
    wp_enqueue_script('casadepiedra-app', get_template_directory_uri() . '/assets/js/app.js', array('gsap', 'gsap-scrolltrigger', 'glightbox'), '3.5.0', true);
}
add_action('wp_enqueue_scripts', 'casadepiedra_scripts');

function casadepiedra_admin_scripts($hook) {
    if (in_array($hook, array('post.php', 'post-new.php'))) {
        wp_enqueue_media();
        wp_enqueue_script('casadepiedra-admin-gallery', get_template_directory_uri() . '/assets/js/admin-gallery.js', array('jquery'), null, true);
    }
}
add_action('admin_enqueue_scripts', 'casadepiedra_admin_scripts');

// 3. Register Custom Post Types
function casadepiedra_register_cpts() {
    // CPT: Espacios
    register_post_type('espacios', array(
        'labels' => array(
            'name' => 'Espacios',
            'singular_name' => 'Espacio',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Espacio',
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-location-alt',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'espacios'),
    ));

    // CPT: Restaurantes
    register_post_type('restaurantes', array(
        'labels' => array(
            'name' => 'Restaurantes',
            'singular_name' => 'Restaurante',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Restaurante',
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-rest-api',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'restaurantes'),
    ));

    // CPT: Galería de Fotos
    register_post_type('galeria_fotos', array(
        'labels' => array(
            'name' => 'Fotos de Galería',
            'singular_name' => 'Foto',
            'add_new' => 'Añadir Nueva Foto',
            'add_new_item' => 'Añadir Nueva Foto a la Galería',
        ),
        'public' => true,
        'has_archive' => false,
        'menu_icon' => 'dashicons-camera',
        'supports' => array('title', 'thumbnail'),
    ));

    // CPT: Eventos
    register_post_type('eventos', array(
        'labels' => array(
            'name' => 'Eventos',
            'singular_name' => 'Evento',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Evento',
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-calendar-alt',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite' => array('slug' => 'eventos'),
    ));
}
add_action('init', 'casadepiedra_register_cpts');

// 4. Meta Boxes para Restaurantes
function casadepiedra_add_restaurante_meta() {
    add_meta_box('casadepiedra_restaurante_info', 'Información del Restaurante', 'casadepiedra_restaurante_meta_callback', 'restaurantes', 'normal', 'high');
}
add_action('add_meta_boxes', 'casadepiedra_add_restaurante_meta');

function casadepiedra_restaurante_meta_callback($post) {
    wp_nonce_field('casadepiedra_save_restaurante_meta', 'casadepiedra_restaurante_meta_nonce');
    
    $menu_url = get_post_meta($post->ID, '_restaurante_menu', true);
    $telefono = get_post_meta($post->ID, '_restaurante_telefono', true);
    $horarios = get_post_meta($post->ID, '_restaurante_horario', true);
    
    echo '<p><label for="restaurante_menu"><strong>Enlace al Menú (URL o PDF):</strong></label><br/>';
    echo '<input type="url" id="restaurante_menu" name="restaurante_menu" value="' . esc_attr($menu_url) . '" style="width:100%;" /></p>';
    
    echo '<p><label for="restaurante_telefono"><strong>Teléfono de Contacto:</strong></label><br/>';
    echo '<input type="text" id="restaurante_telefono" name="restaurante_telefono" value="' . esc_attr($telefono) . '" style="width:100%;" /></p>';
    
    echo '<p><label for="restaurante_horario"><strong>Horarios:</strong></label><br/>';
    echo '<input type="text" id="restaurante_horario" name="restaurante_horario" value="' . esc_attr($horarios) . '" style="width:100%;" placeholder="Ej: Lunes a Domingo de 1pm a 11pm" /></p>';
}

function casadepiedra_save_restaurante_meta($post_id) {
    if (!isset($_POST['casadepiedra_restaurante_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_restaurante_meta_nonce'], 'casadepiedra_save_restaurante_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    if (isset($_POST['restaurante_menu'])) {
        update_post_meta($post_id, '_restaurante_menu', esc_url_raw($_POST['restaurante_menu']));
    }
    if (isset($_POST['restaurante_telefono'])) {
        update_post_meta($post_id, '_restaurante_telefono', sanitize_text_field($_POST['restaurante_telefono']));
    }
    if (isset($_POST['restaurante_horario'])) {
        update_post_meta($post_id, '_restaurante_horario', sanitize_text_field($_POST['restaurante_horario']));
    }
}
add_action('save_post_restaurantes', 'casadepiedra_save_restaurante_meta');

// 5. Customizer para Footer Global
function casadepiedra_customizer($wp_customize) {
    $wp_customize->add_section('footer_options', array('title' => 'Datos Globales y Footer'));
    
    $wp_customize->add_setting('footer_address', array('default' => 'Blvd. Juan Alonso de Torres 2002, Col. Valle del Campestre, León, Gto.'));
    $wp_customize->add_control('footer_address', array('label' => 'Dirección', 'section' => 'footer_options', 'type' => 'textarea'));
    
    $wp_customize->add_setting('footer_phone', array('default' => '477 717 2600'));
    $wp_customize->add_control('footer_phone', array('label' => 'Teléfono', 'section' => 'footer_options', 'type' => 'text'));
    
    $wp_customize->add_setting('footer_email', array('default' => 'eventos@casadepiedraleon.mx'));
    $wp_customize->add_control('footer_email', array('label' => 'Correo', 'section' => 'footer_options', 'type' => 'text'));

    // Textos de Secciones
    $wp_customize->add_section('section_texts', array('title' => 'Textos de Secciones y Archivos'));
    
    $wp_customize->add_setting('text_espacios_title', array('default' => 'Nuestros Espacios'));
    $wp_customize->add_control('text_espacios_title', array('label' => 'Título de Espacios', 'section' => 'section_texts', 'type' => 'text'));
    $wp_customize->add_setting('text_espacios_desc', array('default' => 'Lugares mágicos diseñados para hacer de tu evento una experiencia inolvidable.'));
    $wp_customize->add_control('text_espacios_desc', array('label' => 'Subtítulo de Espacios', 'section' => 'section_texts', 'type' => 'textarea'));
    
    $wp_customize->add_setting('text_restaurantes_title', array('default' => 'Nuestros Restaurantes'));
    $wp_customize->add_control('text_restaurantes_title', array('label' => 'Título de Restaurantes', 'section' => 'section_texts', 'type' => 'text'));
    $wp_customize->add_setting('text_restaurantes_desc', array('default' => 'Disfruta de una experiencia culinaria inigualable en nuestros restaurantes de clase mundial.'));
    $wp_customize->add_control('text_restaurantes_desc', array('label' => 'Subtítulo de Restaurantes', 'section' => 'section_texts', 'type' => 'textarea'));
    
    $wp_customize->add_setting('text_historia_title', array('default' => 'Nuestra Historia'));
    $wp_customize->add_control('text_historia_title', array('label' => 'Título de Quiénes Somos', 'section' => 'section_texts', 'type' => 'text'));
    $wp_customize->add_setting('text_historia_desc', array('default' => 'Testigo de grandeza y refinamiento a lo largo de los siglos.'));
    $wp_customize->add_control('text_historia_desc', array('label' => 'Subtítulo de Quiénes Somos', 'section' => 'section_texts', 'type' => 'textarea'));

    // Textos de Eventos
    $wp_customize->add_setting('text_eventos_title', array('default' => 'Eventos'));
    $wp_customize->add_control('text_eventos_title', array('label' => 'Título de Eventos', 'section' => 'section_texts', 'type' => 'text'));
    $wp_customize->add_setting('text_eventos_desc', array('default' => 'Especialidades a tu medida.'));
    $wp_customize->add_control('text_eventos_desc', array('label' => 'Subtítulo de Eventos', 'section' => 'section_texts', 'type' => 'textarea'));
    
    $wp_customize->add_setting('text_eventos_sociales_desc', array('default' => 'Hacemos de tus fechas más importantes, momentos verdaderamente eternos.'));
    $wp_customize->add_control('text_eventos_sociales_desc', array('label' => 'Texto Sociales', 'section' => 'section_texts', 'type' => 'textarea'));
    
    $wp_customize->add_setting('text_eventos_empresariales_desc', array('default' => 'Proyecta la mejor imagen de tu empresa con infraestructura de primer nivel.'));
    $wp_customize->add_control('text_eventos_empresariales_desc', array('label' => 'Texto Empresariales', 'section' => 'section_texts', 'type' => 'textarea'));
}
add_action('customize_register', 'casadepiedra_customizer');

// 6. Meta Boxes para Cabecera (Hero) en Páginas
function casadepiedra_add_hero_meta() { 
    add_meta_box('casadepiedra_hero', 'Opciones de Cabecera (Hero)', 'casadepiedra_hero_callback', 'page', 'normal', 'high'); 
}
add_action('add_meta_boxes', 'casadepiedra_add_hero_meta');

function casadepiedra_hero_callback($post) {
    echo '<p><label><strong>Subtítulo:</strong></label><br><input type="text" name="_hero_subtitle" value="'.esc_attr(get_post_meta($post->ID, '_hero_subtitle', true)).'" style="width:100%;"></p>';
    echo '<p><label><strong>Título Principal (HTML permitido):</strong></label><br><textarea name="_hero_title" style="width:100%;" rows="3">'.esc_textarea(get_post_meta($post->ID, '_hero_title', true)).'</textarea></p>';
    echo '<p><label><strong>Descripción:</strong></label><br><textarea name="_hero_desc" style="width:100%;" rows="3">'.esc_textarea(get_post_meta($post->ID, '_hero_desc', true)).'</textarea></p>';
}

function casadepiedra_save_hero_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if(isset($_POST['_hero_subtitle'])) update_post_meta($post_id, '_hero_subtitle', sanitize_text_field($_POST['_hero_subtitle']));
    if(isset($_POST['_hero_title'])) update_post_meta($post_id, '_hero_title', wp_kses_post($_POST['_hero_title']));
    if(isset($_POST['_hero_desc'])) update_post_meta($post_id, '_hero_desc', sanitize_text_field($_POST['_hero_desc']));
}
add_action('save_post_page', 'casadepiedra_save_hero_meta');

// 7. Meta Box para Galería (Restaurantes y Espacios)
function casadepiedra_add_gallery_meta() { 
    $screens = array('restaurantes', 'espacios');
    foreach ($screens as $screen) {
        add_meta_box('casadepiedra_gallery', 'Galería de Imágenes Múltiples', 'casadepiedra_gallery_callback', $screen, 'normal', 'high');
    }
}
add_action('add_meta_boxes', 'casadepiedra_add_gallery_meta');

function casadepiedra_gallery_callback($post) {
    wp_nonce_field('casadepiedra_save_gallery_meta', 'casadepiedra_gallery_meta_nonce');
    $gallery_ids = get_post_meta($post->ID, '_casadepiedra_gallery_ids', true);
    
    echo '<div style="margin-bottom:15px;">';
    echo '<input type="button" id="casadepiedra_upload_gallery_btn" class="button button-primary" value="Seleccionar Imágenes" /> ';
    echo '<input type="button" id="casadepiedra_clear_gallery_btn" class="button" value="Limpiar Galería" />';
    echo '</div>';
    
    echo '<input type="hidden" id="casadepiedra_gallery_ids" name="_casadepiedra_gallery_ids" value="' . esc_attr($gallery_ids) . '" />';
    
    echo '<div id="casadepiedra_gallery_preview" style="display:flex; flex-wrap:wrap; gap:10px;">';
    if (!empty($gallery_ids)) {
        $ids_array = explode(',', $gallery_ids);
        foreach ($ids_array as $id) {
            $img = wp_get_attachment_image_src($id, 'thumbnail');
            if ($img) {
                echo '<div style="display:inline-block; margin-right:10px; margin-bottom:10px; position:relative;"><img src="'.esc_url($img[0]).'" style="max-width:100px; height:auto; display:block;" /></div>';
            }
        }
    }
    echo '</div>';
}

function casadepiedra_save_gallery_meta($post_id) {
    if (!isset($_POST['casadepiedra_gallery_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_gallery_meta_nonce'], 'casadepiedra_save_gallery_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['_casadepiedra_gallery_ids'])) {
        update_post_meta($post_id, '_casadepiedra_gallery_ids', sanitize_text_field($_POST['_casadepiedra_gallery_ids']));
    }
}
add_action('save_post', 'casadepiedra_save_gallery_meta');

// 8. Meta Box para Espacios (Capacidad)
function casadepiedra_add_espacio_meta() {
    add_meta_box('casadepiedra_espacio_info', 'Información del Espacio', 'casadepiedra_espacio_meta_callback', 'espacios', 'normal', 'high');
}
add_action('add_meta_boxes', 'casadepiedra_add_espacio_meta');

function casadepiedra_espacio_meta_callback($post) {
    wp_nonce_field('casadepiedra_save_espacio_meta', 'casadepiedra_espacio_meta_nonce');
    $capacidad = get_post_meta($post->ID, '_espacio_capacidad', true);
    
    echo '<p><label for="espacio_capacidad"><strong>Capacidad de Personas:</strong></label><br/>';
    echo '<input type="text" id="espacio_capacidad" name="espacio_capacidad" value="' . esc_attr($capacidad) . '" style="width:100%;" placeholder="Ej: 1,000" /></p>';
    echo '<p class="description">Introduce solo el número o texto corto. Ejemplo: "1,000" (se mostrará como "Hasta 1,000 personas").</p>';
}

function casadepiedra_save_espacio_meta($post_id) {
    if (!isset($_POST['casadepiedra_espacio_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_espacio_meta_nonce'], 'casadepiedra_save_espacio_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['espacio_capacidad'])) {
        update_post_meta($post_id, '_espacio_capacidad', sanitize_text_field($_POST['espacio_capacidad']));
    }
}
add_action('save_post_espacios', 'casadepiedra_save_espacio_meta');

// 9. Meta Box para Eventos (Botón y Enlace)
function casadepiedra_add_evento_meta() {
    add_meta_box('casadepiedra_evento_info', 'Información del Evento', 'casadepiedra_evento_meta_callback', 'eventos', 'normal', 'high');
}
add_action('add_meta_boxes', 'casadepiedra_add_evento_meta');

function casadepiedra_evento_meta_callback($post) {
    wp_nonce_field('casadepiedra_save_evento_meta', 'casadepiedra_evento_meta_nonce');
    $btn_texto = get_post_meta($post->ID, '_evento_boton_texto', true) ?: 'Me interesa';
    $btn_enlace = get_post_meta($post->ID, '_evento_enlace', true);
    
    echo '<p><label for="evento_boton_texto"><strong>Texto del Botón:</strong></label><br/>';
    echo '<input type="text" id="evento_boton_texto" name="evento_boton_texto" value="' . esc_attr($btn_texto) . '" style="width:100%;" placeholder="Ej: Me interesa" /></p>';
    
    echo '<p><label for="evento_enlace"><strong>Enlace Externo (Boletera / WhatsApp):</strong></label><br/>';
    echo '<input type="url" id="evento_enlace" name="evento_enlace" value="' . esc_attr($btn_enlace) . '" style="width:100%;" placeholder="https://" /></p>';
    echo '<p class="description">Este es el enlace al que irá el usuario al dar clic en la tarjeta.</p>';
}

function casadepiedra_save_evento_meta($post_id) {
    if (!isset($_POST['casadepiedra_evento_meta_nonce']) || !wp_verify_nonce($_POST['casadepiedra_evento_meta_nonce'], 'casadepiedra_save_evento_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    
    if (isset($_POST['evento_boton_texto'])) {
        update_post_meta($post_id, '_evento_boton_texto', sanitize_text_field($_POST['evento_boton_texto']));
    }
    if (isset($_POST['evento_enlace'])) {
        update_post_meta($post_id, '_evento_enlace', esc_url_raw($_POST['evento_enlace']));
    }
}
add_action('save_post_eventos', 'casadepiedra_save_evento_meta');

// 7. Cargar script de auto-poblado (Páginas, CPTs y Accesos Directos)
require_once get_template_directory() . '/inc/populate.php';

// Restaurar enlace de Eventos en el menú principal tras borrar la página
function casadepiedra_restore_eventos_menu_link() {
    // Solo purgar reglas de reescritura una vez para que el CPT /eventos/ no dé 404
    if (!get_option('casadepiedra_rewrites_flushed_eventos')) {
        flush_rewrite_rules();
        update_option('casadepiedra_rewrites_flushed_eventos', true);
    }

    $menu_name = 'Menú Principal Premium';
    $menu_exists = wp_get_nav_menu_object($menu_name);
    
    if ($menu_exists) {
        $items = wp_get_nav_menu_items($menu_exists->term_id);
        $has_eventos = false;
        
        // El link "Eventos" en el menú puede ser de tipo 'post_type' (página) o 'custom' (nuestro link).
        if ($items) {
            foreach ($items as $item) {
                if ($item->title === 'Eventos') {
                    $has_eventos = true;
                    // Si el usuario borró la página, el ítem del menú suele quedar huérfano y puede dar problemas.
                    // Si el objeto ya no existe, el title podría estar vacío, pero revisamos por si acaso.
                    break;
                }
            }
        }
        
        // Si no se encontró ningún ítem titulado "Eventos" válido, lo inyectamos.
        if (!$has_eventos) {
            wp_update_nav_menu_item($menu_exists->term_id, 0, array(
                'menu-item-title'  => 'Eventos',
                'menu-item-url'    => home_url('/eventos/'),
                'menu-item-status' => 'publish',
                'menu-item-type'   => 'custom',
            ));
        }
    }
}
add_action('init', 'casadepiedra_restore_eventos_menu_link', 99);

// Forzar que la URL /eventos/ SIEMPRE cargue la plantilla de tarjetas, 
// incluso si el usuario crea accidentalmente una Página estática llamada "Eventos".
function casadepiedra_force_eventos_template($template) {
    if (is_post_type_archive('eventos') || is_page('eventos')) {
        $archive_template = locate_template('archive-eventos.php');
        if ($archive_template) {
            return $archive_template;
        }
    }
    return $template;
}
add_filter('template_include', 'casadepiedra_force_eventos_template', 99);