<?php
/**
 * Template Name: Archivo de Espacios
 * Description: Plantilla para mostrar el grid de espacios.
 */
get_header(); ?>

<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 6rem;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center;">
            <span class="text-script" style="font-size: 3rem;"><?php echo esc_html(get_theme_mod('text_espacios_title', 'Nuestros Espacios')); ?></span>
            <h2 class="text-h2" style="margin-top: 1rem;"><?php echo esc_html(get_theme_mod('text_espacios_desc', 'Escenarios majestuosos.')); ?></h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-12 gap-8">
            <?php
            $args = array(
                'post_type'      => 'espacios',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC'
            );
            $espacios_query = new WP_Query($args);
            $index = 0;

            if ($espacios_query->have_posts()) :
                while ($espacios_query->have_posts()) : $espacios_query->the_post(); 
                    // Alternar tamaño de la tarjeta para crear la disparidad
                    $isLarge = ($index % 4 === 0 || $index % 4 === 3);
                    $colClass = $isLarge ? 'md:col-span-8' : 'md:col-span-4';
                    $height = $isLarge ? '500px' : '400px';
                    
                    // Extraer número de capacidad del meta box
                    $cap_meta = get_post_meta(get_the_ID(), '_espacio_capacidad', true);
                    $capacity = !empty($cap_meta) ? $cap_meta : 'variada';
                ?>
                    
                    <div class="reveal-text <?php echo $colClass; ?>">
                        <a href="<?php the_permalink(); ?>" style="text-decoration: none; display: block; height: 100%;">
                            <div class="luxury-card group" style="height: <?php echo $height; ?>; display: flex; flex-direction: column; overflow: hidden; position: relative;">
                                
                                <?php if (has_post_thumbnail()) : ?>
                                    <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover group-hover:scale-105" loading="lazy" style="position: absolute; inset: 0; z-index: 0; transition: transform 0.7s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';" />
                                <?php else : ?>
                                    <div class="img-cover" style="position: absolute; inset: 0; z-index: 0; background-color: var(--color-surface);"></div>
                                <?php endif; ?>
                                
                                <!-- Soft dark gradient at bottom for text readability -->
                                <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10,10,10,0.9) 0%, rgba(10,10,10,0) 70%); z-index: 1; pointer-events: none;"></div>

                                <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 2rem; z-index: 2; color: var(--color-text-primary);">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-end;">
                                        <div>
                                            <span style="display: inline-block; padding: 4px 12px; border-radius: 9999px; background: rgba(255,255,255,0.1); backdrop-filter: blur(8px); font-size: 0.75rem; font-weight: 600; letter-spacing: 0.05em; margin-bottom: 1rem; text-transform: uppercase; color: var(--color-accent);">
                                                Hasta <?php echo esc_html($capacity); ?> personas
                                            </span>
                                            <h3 class="text-h3" style="margin: 0; text-shadow: 0 2px 10px rgba(0,0,0,0.5);">
                                                <?php the_title(); ?>
                                            </h3>
                                        </div>
                                        
                                        <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--color-accent); color: #000; display: flex; align-items: center; justify-content: center; transform: translateX(-10px) translateY(10px) scale(0); opacity: 0; transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);" class="hover-arrow" onmouseover="this.style.transform='none'; this.style.opacity='1';" onmouseout="this.style.transform='translateX(-10px) translateY(10px) scale(0)'; this.style.opacity='0';">
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                <path d="M5 12h14M12 5l7 7-7 7" />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                <?php 
                    $index++;
                endwhile;
                wp_reset_postdata();
            else : ?>
                <p style="text-align: center; grid-column: 1 / -1; color: var(--color-text-secondary);">Próximamente nuevos espacios.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
/* CSS para emular los estados hover del group-hover de Tailwind/React */
.luxury-card:hover .hover-arrow {
    transform: none !important;
    opacity: 1 !important;
}
.luxury-card:hover .img-cover {
    transform: scale(1.05);
}
</style>

<?php get_footer(); ?>
