    </main> <!-- Cerrando main de header.php -->
    
    <footer style="background-color: #050505; border-top: 1px solid var(--color-border); padding-top: 4rem; padding-bottom: 2rem;">
        <div class="container">
            <div class="grid md:grid-cols-12 gap-12" style="padding-bottom: 4rem;">
                
                <!-- Brand & Socials -->
                <div class="md:col-span-4" style="display: flex; flex-direction: column; gap: 1.5rem;">
                    <img 
                        src="https://casadepiedraleon.mx/wp-content/uploads/2023/09/Logo_Footer.png" 
                        alt="Casa de Piedra" 
                        style="width: 180px; opacity: 0.9;" 
                    />
                    <p class="text-body-lg" style="font-size: 0.9rem; max-width: 300px;">
                        La sede más emblemática de León, Guanajuato. Eventos sociales y empresariales de alto nivel desde 1845.
                    </p>
                    <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                        <a href="https://instagram.com" target="_blank" rel="noreferrer" style="color: var(--color-accent); padding: 0.5rem 0.8rem; border: 1px solid var(--color-border); border-radius: var(--radius-pill); text-decoration: none; font-family: var(--font-heading); font-weight: 600;">
                            Instagram
                        </a>
                        <a href="https://facebook.com" target="_blank" rel="noreferrer" style="color: var(--color-accent); padding: 0.5rem 0.8rem; border: 1px solid var(--color-border); border-radius: var(--radius-pill); text-decoration: none; font-family: var(--font-heading); font-weight: 600;">
                            Facebook
                        </a>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="md:col-span-4" style="display: flex; flex-direction: column; gap: 1.5rem;">
                    <h4 style="color: var(--color-text-primary); font-size: 1.2rem; font-family: var(--font-heading);">Contacto</h4>
                    <div style="display: flex; flex-direction: column; gap: 1rem;">
                        <div style="display: flex; gap: 1rem; align-items: flex-start; color: var(--color-text-secondary);">
                            <span style="color: var(--color-accent); flex-shrink: 0; margin-top: 4px;">📍</span>
                            <span><?php echo esc_html(get_theme_mod('footer_address', 'Blvd. Juan Alonso de Torres 2002, Col. Valle del Campestre, León, Gto.')); ?></span>
                        </div>
                        <div style="display: flex; gap: 1rem; align-items: center; color: var(--color-text-secondary);">
                            <span style="color: var(--color-accent); flex-shrink: 0;">📞</span>
                            <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', get_theme_mod('footer_phone', '477 717 2600'))); ?>" style="color: inherit; text-decoration: none;">
                                <?php echo esc_html(get_theme_mod('footer_phone', '477 717 2600 (Ext. 502)')); ?>
                            </a>
                        </div>
                        <div style="display: flex; gap: 1rem; align-items: center; color: var(--color-text-secondary);">
                            <span style="color: var(--color-accent); flex-shrink: 0;">✉️</span>
                            <a href="mailto:<?php echo esc_attr(get_theme_mod('footer_email', 'eventos@casadepiedraleon.mx')); ?>" style="color: inherit; text-decoration: none;">
                                <?php echo esc_html(get_theme_mod('footer_email', 'eventos@casadepiedraleon.mx')); ?>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="md:col-span-4" style="display: flex; flex-direction: column; gap: 1.5rem;">
                    <h4 style="color: var(--color-text-primary); font-size: 1.2rem; font-family: var(--font-heading);">Enlaces</h4>
                    <?php 
                    if(has_nav_menu('menu-footer')) {
                        wp_nav_menu(array(
                            'theme_location' => 'menu-footer',
                            'container' => false,
                            'menu_class' => 'footer-links',
                        ));
                    } else {
                        // Fallback
                        wp_nav_menu(array(
                            'theme_location' => 'menu-principal',
                            'container' => false,
                            'menu_class' => 'footer-links',
                        ));
                    }
                    ?>
                    <style>
                        .footer-links { list-style: none; display: flex; flex-direction: column; gap: 0.75rem; padding: 0; margin: 0; }
                        .footer-links a { color: var(--color-text-secondary); text-decoration: none; transition: color 0.3s; }
                        .footer-links a:hover { color: var(--color-accent); }
                    </style>
                </div>
            </div>

            <div style="border-top: 1px solid var(--color-border); padding-top: 2rem; display: flex; flex-direction: column; justify-content: space-between; align-items: center; gap: 1rem; text-align: center; color: var(--color-text-secondary); font-size: 0.8rem;">
                <div>COPYRIGHT © <?php echo date('Y'); ?> CASA DE PIEDRA. TODOS LOS DERECHOS RESERVADOS.</div>
                <a href="<?php echo esc_url(home_url('/aviso-de-privacidad')); ?>" style="color: inherit; text-decoration: underline;">Aviso de Privacidad</a>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>