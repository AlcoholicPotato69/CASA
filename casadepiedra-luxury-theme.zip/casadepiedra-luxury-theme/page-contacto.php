<?php
/**
 * Template Name: Contacto
 * Description: Plantilla para la página de contacto.
 */
get_header(); ?>

<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 6rem;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center;">
            <span class="text-script" style="font-size: 3rem;">Contacto</span>
            <h2 class="text-h2" style="margin-top: 1rem;">Escribe tu historia aquí.</h2>
        </div>

        <div class="grid md:grid-cols-2 gap-12">
            <!-- Info -->
            <div class="reveal-text luxury-card" style="padding: 3rem;">
                <h3 class="text-h3" style="margin-bottom: 2rem; color: var(--color-accent);">Ponte en contacto</h3>
                
                <div style="margin-bottom: 2rem;">
                    <span class="text-caption">Horario de Oficina</span>
                    <p class="text-body-lg">Lunes a Viernes 8:30 hrs – 17:30 hrs.</p>
                </div>
                
                <div style="margin-bottom: 2rem;">
                    <span class="text-caption">Teléfono</span>
                    <p class="text-body-lg"><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', get_theme_mod('footer_phone', '477 717 2600'))); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html(get_theme_mod('footer_phone', '477 717 2600 (Ext. 502)')); ?></a></p>
                </div>

                <div style="margin-bottom: 3rem;">
                    <span class="text-caption">Correo</span>
                    <p class="text-body-lg"><a href="mailto:<?php echo esc_attr(get_theme_mod('footer_email', 'eventos@casadepiedraleon.mx')); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html(get_theme_mod('footer_email', 'eventos@casadepiedraleon.mx')); ?></a></p>
                </div>

                <a href="mailto:<?php echo esc_attr(get_theme_mod('footer_email', 'eventos@casadepiedraleon.mx')); ?>" style="display: inline-block; padding: 1rem 2.5rem; background: var(--color-accent); color: #000; border-radius: 9999px; text-decoration: none; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                    Solicitar Cotización
                </a>
                
                <!-- Opcional: Shortcode de Elementor o Contact Form 7 -->
                <div style="margin-top: 2rem;">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); the_content(); endwhile; endif; ?>
                </div>
            </div>

            <!-- Map -->
            <div class="reveal-text luxury-card" style="height: 400px;">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3662.6833868418894!2d-101.7002938!3d21.159507649999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842bbf53a2e4d0e3%3A0xfe1f47b7b2f6b0a3!2sCasa%20De%20Piedra!5e1!3m2!1ses-419!2smx!4v1779525259315!5m2!1ses-419!2smx" 
                    width="100%" 
                    height="100%" 
                    style="border: 0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
