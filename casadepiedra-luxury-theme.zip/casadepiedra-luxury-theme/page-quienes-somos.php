<?php
/**
 * Template Name: Quiénes Somos
 * Description: Plantilla para la página de historia/nosotros.
 */
get_header(); ?>

<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 6rem;">
    <section class="section">
        <div class="container">
            <div class="grid md:grid-cols-2 gap-12 align-center">
                <div class="reveal-text">
                    <span class="text-script" style="font-size: 3rem;"><?php echo esc_html(get_theme_mod('text_historia_title', 'Nuestra Historia')); ?></span>
                    <h2 class="text-h2" style="margin-bottom: 4rem; margin-top: 1rem;">
                        <?php echo esc_html(get_theme_mod('text_historia_desc', 'Testigo de grandeza y refinamiento a lo largo de los siglos.')); ?>
                    </h2>
                </div>
                
                <div class="reveal-text luxury-card grid md:grid-cols-2 gap-8" style="padding: clamp(1.5rem, 5vw, 4rem); text-align: left;">
                    <div>
                        <div class="text-body-lg" style="margin-bottom: 1.5rem;">
                            <!-- El contenido editable de la página se inyecta aquí -->
                            <?php 
                            if (have_posts()) : while (have_posts()) : the_post();
                                if(empty(get_the_content())) {
                                    echo '<p style="margin-bottom: 1.5rem;">En el corazón de nuestra querida ciudad se erige la sublime ex hacienda, Casa de Piedra. Fundada en 1845, es famosa por su arquitectura y tradición incomparable.</p><p>Gracias a su más reciente remodelación, obra del reconocido arquitecto Jalisciense Roberto Elías, Casa de Piedra se ha transformado en un verdadero paraíso de exclusividad y elegancia.</p>';
                                } else {
                                    the_content();
                                }
                            endwhile; endif; 
                            ?>
                        </div>
                    </div>
                    <div style="position: relative; height: 100%; min-height: 300px;">
                        <?php if (has_post_thumbnail()) : ?>
                            <img src="<?php the_post_thumbnail_url('large'); ?>" alt="Casa de Piedra - Historia" class="img-cover" style="border-radius: var(--radius-md);" />
                        <?php else : ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/terraza_mezquite_1779523084857.png" alt="Casa de Piedra - Historia" class="img-cover" style="border-radius: var(--radius-md);" />
                        <?php endif; ?>
                    </div>
                </div>

                <div class="reveal-text" style="margin-top: 4rem;">
                    <h3 class="text-h3" style="margin-bottom: 2rem;">Nuestra Ubicación</h3>
                    <div class="luxury-card" style="height: 400px;">
                        <iframe 
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3662.6833868418894!2d-101.7002938!3d21.159507649999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842bbf53a2e4d0e3%3A0xfe1f47b7b2f6b0a3!2sCasa%20De%20Piedra!5e1!3m2!1ses-419!2smx!4v1779525259315!5m2!1ses-419!2smx" 
                            width="100%" 
                            height="100%" 
                            style="border: 0;" 
                            allowfullscreen="" 
                            loading="lazy" 
                            referrerpolicy="no-referrer-when-downgrade"
                        ></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php get_footer(); ?>
