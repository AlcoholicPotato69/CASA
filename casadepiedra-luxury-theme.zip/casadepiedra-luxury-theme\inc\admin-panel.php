<?php
/**
 * Panel de Opciones Global (Panel Casa de Piedra)
 */

// 1. Hook para guardar las opciones genéricamente
function casa_save_global_options() {
    if (!current_user_can('manage_options') || !isset($_POST['casa_options_nonce']) || !wp_verify_nonce($_POST['casa_options_nonce'], 'casa_save_options')) {
        wp_die('No tienes permisos o la sesión ha expirado.');
    }

    foreach ($_POST as $key => $value) {
        if (strpos($key, 'casa_opt_') === 0) {
            update_option($key, wp_kses_post(stripslashes($value)));
        }
    }

    wp_redirect(add_query_arg('updated', 'true', wp_get_referer()));
    exit;
}
add_action('admin_post_casa_save_options', 'casa_save_global_options');

// 2. Registrar Menús
function casa_register_admin_panel() {
    add_menu_page(
        'Panel Casa',          
        'Panel Casa',          
        'manage_options',        
        'casa-panel',           
        'casa_admin_page_global', 
        'dashicons-admin-home',
        '2.1'
    );

    add_submenu_page('casa-panel', 'Globales', 'Globales', 'manage_options', 'casa-panel', 'casa_admin_page_global');
    add_submenu_page('casa-panel', 'Inicio', 'Inicio', 'manage_options', 'casa-panel-inicio', 'casa_admin_page_inicio');
    add_submenu_page('casa-panel', 'Quiénes Somos', 'Quiénes Somos', 'manage_options', 'casa-panel-nosotros', 'casa_admin_page_nosotros');
    add_submenu_page('casa-panel', 'Galería', 'Galería', 'manage_options', 'casa-panel-galeria', 'casa_admin_page_galeria');
    add_submenu_page('casa-panel', 'Contacto', 'Contacto', 'manage_options', 'casa-panel-contacto', 'casa_admin_page_contacto');
}
add_action('admin_menu', 'casa_register_admin_panel');

// 3. Funciones Helper
function casa_render_admin_header($title) {
    echo '<div class="wrap" style="max-width:900px; background:#fff; padding:20px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-top:20px;">';
    echo '<h1 style="border-bottom:2px solid #d4af37; padding-bottom:10px; color:#111;">' . esc_html($title) . '</h1>';
    if (isset($_GET['updated']) && $_GET['updated'] == 'true') {
        echo '<div class="updated notice is-dismissible"><p><strong>Ajustes guardados correctamente.</strong></p></div>';
    }
    echo '<form method="POST" action="' . esc_url(admin_url('admin-post.php')) . '">';
    echo '<input type="hidden" name="action" value="casa_save_options">';
    wp_nonce_field('casa_save_options', 'casa_options_nonce');
}

function casa_render_admin_footer() {
    echo '<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary button-large" value="Guardar Cambios"></p>';
    echo '</form></div>';
}

function casa_opt_text($label, $key, $is_textarea = false) {
    $value = get_option($key, '');
    echo '<div style="margin-bottom:15px;"><label style="font-weight:bold;display:block;margin-bottom:5px;">' . esc_html($label) . '</label>';
    if ($is_textarea) {
        echo '<textarea name="'.esc_attr($key).'" style="width:100%;" rows="4">'.esc_textarea($value).'</textarea>';
    } else {
        echo '<input type="text" name="'.esc_attr($key).'" value="'.esc_attr($value).'" style="width:100%;">';
    }
    echo '</div>';
}

function casa_opt_editor($label, $key) {
    $value = get_option($key, '');
    echo '<div style="margin-bottom:15px;">';
    echo '<label style="font-weight:bold;display:block;margin-bottom:10px;">' . esc_html($label) . '</label>';
    wp_editor(stripslashes($value), $key, array('textarea_name' => $key, 'textarea_rows' => 10, 'media_buttons' => true));
    echo '</div>';
}

function casa_opt_image($label, $key) {
    $value = get_option($key, '');
    echo '<div style="margin-bottom:15px; padding:10px; background:#f9f9f9; border:1px solid #ddd;">';
    echo '<label style="font-weight:bold;display:block;margin-bottom:5px;">' . esc_html($label) . '</label>';
    echo '<input type="text" id="'.esc_attr($key).'" name="'.esc_attr($key).'" value="'.esc_attr($value).'" style="width:70%;" /> ';
    echo '<input type="button" class="button casadepiedra_upload_image_btn" data-target="'.esc_attr($key).'" data-preview="preview_'.esc_attr($key).'" value="Subir / Seleccionar" /> ';
    echo '<input type="button" class="button casadepiedra_clear_image_btn" data-target="'.esc_attr($key).'" data-preview="preview_'.esc_attr($key).'" value="Quitar" />';
    echo '<div id="preview_'.esc_attr($key).'"><img src="'.esc_url($value).'" style="max-height:80px; display:block; margin-top:10px;"/></div>';
    echo '</div>';
}

function casa_opt_checkbox($label, $key) {
    $value = get_option($key, '1');
    echo '<div style="margin-bottom:15px; display: flex; align-items: center; gap: 10px;">';
    echo '<input type="hidden" name="'.esc_attr($key).'" value="0">';
    echo '<input type="checkbox" name="'.esc_attr($key).'" value="1" ' . checked($value, '1', false) . ' style="margin: 0; width: 18px; height: 18px;">';
    echo '<label style="font-weight:bold; cursor: pointer;">' . esc_html($label) . '</label>';
    echo '</div>';
}

/* ================= PAGINAS DE OPCIONES ================= */

// GLOBAL
function casa_admin_page_global() {
    casa_render_admin_header('Panel Casa: Ajustes Globales');
    
    echo '<h2>Logotipo y Branding</h2>';
    casa_opt_image('Logotipo Principal', 'casa_opt_global_logo');
    
    echo '<hr><h2>Datos de Contacto (Footer)</h2>';
    casa_opt_text('Dirección de las instalaciones', 'casa_opt_global_address', true);
    casa_opt_text('Teléfono', 'casa_opt_global_phone');
    casa_opt_text('Correo de contacto', 'casa_opt_global_email');

    echo '<hr><h2>Textos de Archivos y Secciones</h2>';
    casa_opt_text('Título "Nuestros Espacios"', 'casa_opt_global_espacios_title');
    casa_opt_text('Descripción "Nuestros Espacios"', 'casa_opt_global_espacios_desc', true);
    casa_opt_image('Imagen de Portada (Header)', 'casa_opt_espacios_portada');
    
    echo '<hr>';
    casa_opt_text('Título "Nuestros Restaurantes"', 'casa_opt_global_restaurantes_title');
    casa_opt_text('Descripción "Nuestros Restaurantes"', 'casa_opt_global_restaurantes_desc', true);
    casa_opt_image('Imagen de Portada (Header)', 'casa_opt_restaurantes_portada');

    echo '<hr>';
    casa_opt_text('Título "Eventos"', 'casa_opt_global_eventos_title');
    casa_opt_text('Descripción "Eventos"', 'casa_opt_global_eventos_desc', true);
    casa_opt_image('Imagen de Portada (Header)', 'casa_opt_eventos_portada');

    echo '<hr><h2>Estado de Secciones (Activas / Inactivas)</h2>';
    echo '<p class="description" style="margin-bottom: 20px; color:#666;">Marca o desmarca las secciones para activarlas o desactivarlas en los menús de navegación. Si una sección está desactivada, el acceso directo a su página se redirigirá automáticamente a la página de Inicio.</p>';
    casa_opt_checkbox('Activar "Quiénes Somos"', 'casa_opt_status_nosotros');
    casa_opt_checkbox('Activar "Espacios"', 'casa_opt_status_espacios');
    casa_opt_checkbox('Activar "Restaurantes"', 'casa_opt_status_restaurantes');
    casa_opt_checkbox('Activar "Galería"', 'casa_opt_status_galeria');
    casa_opt_checkbox('Activar "Eventos"', 'casa_opt_status_eventos');
    casa_opt_checkbox('Activar "Contacto"', 'casa_opt_status_contacto');

    casa_render_admin_footer();
}

// INICIO
function casa_admin_page_inicio() {
    casa_render_admin_header('Panel Casa: Página de Inicio');
    
    echo '<h2>Hero (Sección Principal)</h2>';
    casa_opt_image('Imagen de Fondo', 'casa_opt_home_hero_img');
    casa_opt_text('Subtítulo (Ej. Desde 1845)', 'casa_opt_home_hero_subtitle');
    casa_opt_text('Título Principal (H1)', 'casa_opt_home_hero_title', true);
    casa_opt_text('Descripción', 'casa_opt_home_hero_desc', true);

    casa_render_admin_footer();
}

// QUIÉNES SOMOS
function casa_admin_page_nosotros() {
    casa_render_admin_header('Panel Casa: Quiénes Somos');
    
    echo '<h2>Sección Principal</h2>';
    casa_opt_image('Imagen de Portada Gigante (Header)', 'casa_opt_nosotros_portada');
    casa_opt_image('Imagen Destacada', 'casa_opt_nosotros_hero_img');
    casa_opt_text('Título Principal', 'casa_opt_nosotros_title', true);
    casa_opt_text('Subtítulo de la sección', 'casa_opt_nosotros_subtitle', true);
    casa_opt_editor('Descripción / Texto principal', 'casa_opt_nosotros_desc');

    casa_render_admin_footer();
}

// CONTACTO
function casa_admin_page_contacto() {
    casa_render_admin_header('Panel Casa: Página de Contacto');
    
    echo '<h2>Información de Contacto</h2>';
    casa_opt_image('Imagen de Portada (Header)', 'casa_opt_contacto_portada');
    casa_opt_text('Título de la página', 'casa_opt_contacto_title', true);
    casa_opt_text('Descripción breve', 'casa_opt_contacto_desc', true);
    casa_opt_text('URL de Google Maps (Iframe SRC)', 'casa_opt_contacto_map', true);

    casa_render_admin_footer();
}

// GALERIA
function casa_admin_page_galeria() {
    casa_render_admin_header('Panel Casa: Galería Collage');
    
    echo '<h2>Configuración Principal</h2>';
    casa_opt_image('Imagen de Portada Gigante', 'casa_opt_galeria_portada');
    
    echo '<hr><h2>Carga Masiva de Imágenes</h2>';
    echo '<p class="description">Sube todas las fotos de tu galería aquí. Para hacer que una foto sea "<strong>Estelar</strong>" (más grande en el collage), haz clic en la imagen dentro de la biblioteca de medios y escribe la palabra <strong>estelar</strong> en el campo <strong>Leyenda</strong> (Caption) o <strong>Descripción</strong>.</p>';
    
    $gallery_ids = get_option('casa_opt_galeria_imagenes', '');
    
    echo '<div style="margin-bottom:15px; padding: 20px; background: #f9f9f9; border: 1px solid #ddd;">';
    echo '<input type="button" id="casadepiedra_upload_gallery_btn" class="button button-primary button-large" value="Seleccionar Múltiples Imágenes" /> ';
    echo '<input type="button" id="casadepiedra_clear_gallery_btn" class="button button-large" value="Limpiar Galería" />';
    echo '</div>';
    
    echo '<input type="hidden" id="casadepiedra_gallery_ids" name="casa_opt_galeria_imagenes" value="' . esc_attr($gallery_ids) . '" />';
    
    echo '<div id="casadepiedra_gallery_preview" style="display:flex; flex-wrap:wrap; gap:10px; margin-bottom: 20px;">';
    if (!empty($gallery_ids)) {
        $ids_array = explode(',', $gallery_ids);
        foreach ($ids_array as $id) {
            $img = wp_get_attachment_image_src($id, 'thumbnail');
            if ($img) {
                echo '<div style="display:inline-block; margin-right:10px; margin-bottom:10px; position:relative;"><img src="'.esc_url($img[0]).'" style="max-width:100px; height:auto; display:block; border: 2px solid #ddd;" /></div>';
            }
        }
    }
    echo '</div>';

    casa_render_admin_footer();
}
