<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php wp_head(); ?>
    <style>
        /* Navbar specific styles that were inline in React */
        .header-wrapper {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 100; 
            padding: 1rem clamp(1rem, 4vw, 2rem);
            background: rgba(10, 10, 10, 0.4);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-logo {
            height: 3.75rem;
            object-fit: contain;
            cursor: pointer;
        }
        .desktop-nav ul {
            display: flex;
            align-items: center;
            gap: 2rem;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .desktop-nav a {
            font-family: var(--font-body);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.15em;
            color: var(--color-text-primary);
            text-decoration: none;
            transition: color 0.3s;
        }
        .desktop-nav a:hover,
        .desktop-nav .current-menu-item > a {
            color: var(--color-accent) !important;
        }
        .mobile-hamburger {
            background: rgba(20,20,20,0.8);
            backdrop-filter: blur(10px);
            border: 1px solid var(--color-border);
            border-radius: 50%;
            cursor: pointer;
            flex-direction: column;
            gap: 0.375rem;
            padding: 0;
            z-index: 101;
            width: 3rem; 
            height: 3rem;
            align-items: center;
            justify-content: center;
        }
        .hamburger-line {
            width: 1.5rem;
            height: 0.125rem;
            background-color: var(--color-accent);
            transition: transform 0.4s cubic-bezier(0.32, 0.72, 0, 1), background-color 0.4s;
        }
        /* Active states for hamburger */
        .mobile-hamburger.is-active .hamburger-line:nth-child(1) {
            transform: rotate(45deg) translate(0.3125rem, 0.375rem);
            background-color: var(--color-text-primary);
        }
        .mobile-hamburger.is-active .hamburger-line:nth-child(2) {
            transform: rotate(-45deg) translate(0.3125rem, -0.375rem);
            background-color: var(--color-text-primary);
        }

        .fullscreen-menu {
            position: fixed;
            inset: 0;
            background-color: #0a0a0a;
            z-index: 99;
            clip-path: circle(0% at calc(100% - 40px) 40px);
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: radial-gradient(circle at center, rgba(212,175,55,0.05) 0%, transparent 70%);
        }
        .fullscreen-menu ul {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            text-align: center;
            padding: 0;
            margin: 0;
        }
        .fullscreen-menu li {
            overflow: hidden;
        }
        .fullscreen-menu a {
            font-family: var(--font-heading);
            font-size: clamp(1.8rem, 8vw, 8rem);
            color: var(--color-text-primary);
            text-decoration: none;
            opacity: 0; /* Animated by GSAP */
            transform: translateY(3rem); /* Animated by GSAP */
            display: block;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            transition: color 0.3s;
        }
        .fullscreen-menu a:hover,
        .fullscreen-menu .current-menu-item > a {
            color: var(--color-accent);
        }
    </style>
</head>
<body <?php body_class(); ?>>
    <nav class="header-wrapper">
        <div class="logo-container">
            <?php 
            $panel_logo = get_option('casa_opt_global_logo');
            if ($panel_logo) {
                ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" style="text-decoration: none;">
                    <img src="<?php echo esc_url($panel_logo); ?>" alt="<?php bloginfo('name'); ?>" class="header-logo" />
                </a>
                <?php
            } elseif (has_custom_logo()) {
                the_custom_logo();
            } else {
                ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" style="text-decoration: none;">
                    <img 
                        src="https://casadepiedraleon.mx/wp-content/uploads/2023/09/Logo_Header.png" 
                        alt="<?php bloginfo('name'); ?>" 
                        class="header-logo"
                    />
                </a>
                <?php
            }
            ?>
        </div>
        
        <!-- Desktop Navbar -->
        <div class="desktop-nav">
            <?php 
            wp_nav_menu(array(
                'theme_location' => 'menu-principal',
                'container' => false,
                'fallback_cb' => false
            )); 
            ?>
        </div>

        <!-- Mobile Hamburger -->
        <button class="mobile-nav-btn mobile-hamburger" id="nav-toggle" aria-label="Toggle Menu">
            <div class="hamburger-line"></div>
            <div class="hamburger-line"></div>
        </button>
    </nav>

    <!-- Mobile Fullscreen Menu -->
    <div class="fullscreen-menu" id="fullscreen-menu">
        <?php 
        wp_nav_menu(array(
            'theme_location' => 'menu-principal',
            'container' => false,
            'fallback_cb' => false,
            'menu_id' => 'mobile-menu-list'
        )); 
        ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const currentUrl = window.location.href.split('?')[0].replace(/\/$/, "");
        const navLinks = document.querySelectorAll('.desktop-nav a, .fullscreen-menu a');
        navLinks.forEach(link => {
            const linkUrl = link.getAttribute('href').split('?')[0].replace(/\/$/, "");
            if (linkUrl === currentUrl) {
                link.style.setProperty('color', 'var(--color-accent)', 'important');
            }
        });
    });
    </script>

    <!-- Lenis integration wrapper (optional, for smooth scrolling support) -->
    <main id="main-content">