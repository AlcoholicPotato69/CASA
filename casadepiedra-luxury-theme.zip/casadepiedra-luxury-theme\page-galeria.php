<?php
/**
 * Template Name: Galería
 * Description: Plantilla para la Galería Collage Masonry.
 */
get_header(); 

$portada_url = get_option('casa_opt_galeria_portada');
$gallery_ids_str = get_option('casa_opt_galeria_imagenes', '');
$gallery_ids = !empty($gallery_ids_str) ? explode(',', $gallery_ids_str) : [];

// Paginación
$per_page = 20;
$paged = (get_query_var('paged')) ? get_query_var('paged') : ((get_query_var('page')) ? get_query_var('page') : 1);
$offset = ($paged - 1) * $per_page;
$total_pages = ceil(count($gallery_ids) / $per_page);
$current_ids = array_slice($gallery_ids, $offset, $per_page);

?>

<?php if ($portada_url): ?>
<section style="position: relative; width: 100%; height: 70vh; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 4rem;">
    <img src="<?php echo esc_url($portada_url); ?>" alt="Galería Portada" style="position: absolute; width: 100%; height: 100%; object-fit: cover; z-index: -1; filter: brightness(0.7);" class="gs-zoom-in" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(10,10,10,0.2) 0%, rgba(10,10,10,0.5) 70%, var(--color-bg, #0a0a0a) 100%); z-index: 0; pointer-events: none;"></div>
    <div style="position: relative; z-index: 1; text-align: center;">
        <span class="text-script reveal-text" style="font-size: 4rem; color: #fff;">Nuestra Esencia</span>
        <h1 class="text-hero reveal-text" style="color: #fff; text-shadow: 0 10px 30px rgba(0,0,0,0.5);">Galería</h1>
    </div>
</section>
<?php else: ?>
<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 2rem;">
    <div class="container text-center">
        <span class="text-script" style="font-size: 3rem;">Galería</span>
        <h2 class="text-h2" style="margin-top: 1rem;">Momentos inolvidables.</h2>
    </div>
</div>
<?php endif; ?>

<div class="container" style="padding-bottom: 6rem;">
    <?php if (!empty($current_ids)): ?>
        <div class="gallery-grid">
            <?php foreach ($current_ids as $id): 
                $img_full = wp_get_attachment_image_url($id, 'full');
                $img_thumb = wp_get_attachment_image_url($id, 'large');
                if (!$img_thumb) continue;
                
                // Checar si es estelar manualmente o si es horizontal
                $attachment = get_post($id);
                $caption = $attachment->post_excerpt; // Leyenda
                $desc = $attachment->post_content; // Descripción
                
                $img_meta = wp_get_attachment_image_src($id, 'large');
                $w = isset($img_meta[1]) && $img_meta[1] ? $img_meta[1] : 1;
                $h = isset($img_meta[2]) && $img_meta[2] ? $img_meta[2] : 1;
                $is_horizontal = ($w / $h) > 1.2; // Es apaisada
                
                $is_estelar = (stripos($caption, 'estelar') !== false || stripos($desc, 'estelar') !== false || $is_horizontal);
                $class = $is_estelar ? 'gallery-item estelar reveal-text' : 'gallery-item reveal-text';
            ?>
                <div class="<?php echo esc_attr($class); ?>">
                    <a href="<?php echo esc_url($img_full); ?>" class="glightbox" data-gallery="main-gallery">
                        <img src="<?php echo esc_url($img_thumb); ?>" alt="<?php echo esc_attr($attachment->post_title); ?>" loading="lazy" />
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if ($total_pages > 1): ?>
        <div style="margin-top: 4rem; text-align: center; display: flex; justify-content: center; gap: 1rem;">
            <?php 
            echo paginate_links(array(
                'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                'format' => '?paged=%#%',
                'current' => max(1, $paged),
                'total' => $total_pages,
                'prev_text' => '&laquo; Anterior',
                'next_text' => 'Siguiente &raquo;',
                'type' => 'list',
            ));
            ?>
        </div>
        <style>
            .page-numbers { display: inline-block; padding: 0.5rem 1rem; border: 1px solid var(--color-border); color: var(--color-text-primary); text-decoration: none; border-radius: 4px; transition: all 0.3s; }
            .page-numbers.current, .page-numbers:hover { background: var(--color-accent); color: #000; border-color: var(--color-accent); }
            ul.page-numbers { list-style: none; display: flex; gap: 0.5rem; padding: 0; margin: 0; }
        </style>
        <?php endif; ?>

    <?php else: ?>
        <div class="text-center" style="padding: 4rem 0;">
            <p class="text-body-lg">Aún no hay fotos en la galería.</p>
        </div>
    <?php endif; ?>
</div>



<?php get_footer(); ?>
