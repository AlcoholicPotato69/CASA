<?php
/**
 * Template Name: Galería
 * Description: Plantilla para la Galería Collage Masonry.
 */
get_header(); 

$portada_url = get_option('casa_opt_galeria_portada');
$gallery_ids_str = get_option('casa_opt_galeria_imagenes', '');
$gallery_ids = !empty($gallery_ids_str) ? explode(',', $gallery_ids_str) : [];

// Paginación
$per_page = 20;
$paged = (get_query_var('paged')) ? get_query_var('paged') : ((get_query_var('page')) ? get_query_var('page') : 1);
$offset = ($paged - 1) * $per_page;
$total_pages = ceil(count($gallery_ids) / $per_page);
$current_ids = array_slice($gallery_ids, $offset, $per_page);

?>

<?php if ($portada_url): ?>
<section style="position: relative; width: 100%; height: 70vh; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 4rem;">
    <img src="<?php echo esc_url($portada_url); ?>" alt="Galería Portada" style="position: absolute; width: 100%; height: 100%; object-fit: cover; z-index: -1; filter: brightness(0.7);" class="gs-zoom-in" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(10,10,10,0.2) 0%, rgba(10,10,10,0.5) 70%, var(--color-bg, #0a0a0a) 100%); z-index: 0; pointer-events: none;"></div>
    <div style="position: relative; z-index: 1; text-align: center;">
        <span class="text-script reveal-text" style="font-size: 4rem; color: #fff;">Nuestra Esencia</span>
        <h1 class="text-hero reveal-text" style="color: #fff; text-shadow: 0 10px 30px rgba(0,0,0,0.5);">Galería</h1>
    </div>
</section>
<?php else: ?>
<div style="padding-top: clamp(8rem, 15vh, 12rem); padding-bottom: 2rem;">
    <div class="container text-center">
        <span class="text-script" style="font-size: 3rem;">Galería</span>
        <h2 class="text-h2" style="margin-top: 1rem;">Momentos inolvidables.</h2>
    </div>
</div>
<?php endif; ?>

<div class="container" style="padding-bottom: 6rem;">
    <?php if (!empty($current_ids)): ?>
        <?php 
        $displayed_tags = array();
        $gallery_items_data = array();
        
        foreach ($current_ids as $id) {
            $img_full = wp_get_attachment_image_url($id, 'full');
            $img_thumb = wp_get_attachment_image_url($id, 'large');
            if (!$img_thumb) continue;
            
            $attachment = get_post($id);
            $caption = $attachment->post_excerpt; 
            $desc = $attachment->post_content; 
            
            $img_meta = wp_get_attachment_image_src($id, 'large');
            $w = isset($img_meta[1]) && $img_meta[1] ? $img_meta[1] : 1;
            $h = isset($img_meta[2]) && $img_meta[2] ? $img_meta[2] : 1;
            $is_horizontal = ($w / $h) > 1.2; 
            
            $is_estelar = (stripos($caption, 'estelar') !== false || stripos($desc, 'estelar') !== false || $is_horizontal);
            
            // Extract tags
            $terms = wp_get_object_terms($id, 'galeria_tag');
            $item_tags = array();
            if (!is_wp_error($terms) && !empty($terms)) {
                foreach($terms as $term) {
                    $item_tags[] = $term->slug;
                    $displayed_tags[$term->slug] = $term->name;
                }
            }
            $tags_string = implode(' ', $item_tags);
            $class = $is_estelar ? "gallery-item estelar reveal-text $tags_string" : "gallery-item reveal-text $tags_string";
            
            $gallery_items_data[] = array(
                'full' => $img_full,
                'thumb' => $img_thumb,
                'title' => $attachment->post_title,
                'class' => $class
            );
        }
        ?>

        <?php if (!empty($displayed_tags)): ?>
        <div class="gallery-filters" style="position:relative; text-align:right; margin-bottom:3rem; display:flex; justify-content:flex-end; align-items:center;">
            <button id="filter-toggle" style="background:transparent; border:none; color:var(--color-accent); font-size:1.5rem; cursor:pointer; padding:0.5rem; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.05)';" onmouseout="this.style.background='transparent';" aria-label="Filtros">
                <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35M16.65 16.65A7.5 7.5 0 1110.5 3a7.5 7.5 0 016.15 13.65z"></path></svg>
            </button>
            <div id="filter-dropdown" style="position:absolute; top:100%; right:0; background:#111; border:1px solid var(--color-border); padding:1.5rem; border-radius:1rem; z-index:50; min-width:250px; text-align:left; opacity:0; transform:translateY(10px); pointer-events:none; transition:all 0.3s ease; box-shadow:0 10px 30px rgba(0,0,0,0.5);">
                <h4 style="margin:0 0 1rem 0; font-family:var(--font-heading); color:var(--color-text-primary); font-size:1rem; text-transform:uppercase; letter-spacing:0.1em;">Filtrar Fotos</h4>
                <div style="display:flex; flex-direction:column; gap:0.75rem;">
                    <?php foreach($displayed_tags as $slug => $name): ?>
                    <label style="display:flex; align-items:center; gap:0.5rem; color:var(--color-text-secondary); font-family:var(--font-body); cursor:pointer; user-select:none; transition:color 0.3s;" onmouseover="this.style.color='var(--color-text-primary)';" onmouseout="this.style.color='var(--color-text-secondary)';">
                        <input type="checkbox" class="filter-checkbox" value="<?php echo esc_attr($slug); ?>" style="accent-color:var(--color-accent); width:18px; height:18px; cursor:pointer;">
                        <?php echo esc_html($name); ?>
                    </label>
                    <?php endforeach; ?>
                </div>
                <div style="margin-top:1.5rem; font-size:0.8rem; color:var(--color-accent); font-family:var(--font-body); opacity:0.8;">Máximo 2 filtros simultáneos.</div>
            </div>
        </div>
        
        <script>
        document.addEventListener('DOMContentLoaded', () => {
            const toggleBtn = document.getElementById('filter-toggle');
            const dropdown = document.getElementById('filter-dropdown');
            const checkboxes = document.querySelectorAll('.filter-checkbox');
            const items = document.querySelectorAll('.gallery-item');
            
            let activeFilters = []; // Queue for FIFO (max 2)

            // Toggle dropdown
            toggleBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isOpen = dropdown.style.opacity === '1';
                if (isOpen) {
                    dropdown.style.opacity = '0';
                    dropdown.style.transform = 'translateY(10px)';
                    dropdown.style.pointerEvents = 'none';
                } else {
                    dropdown.style.opacity = '1';
                    dropdown.style.transform = 'translateY(0)';
                    dropdown.style.pointerEvents = 'auto';
                }
            });

            // Close when clicking outside
            document.addEventListener('click', (e) => {
                if (!dropdown.contains(e.target) && e.target !== toggleBtn) {
                    dropdown.style.opacity = '0';
                    dropdown.style.transform = 'translateY(10px)';
                    dropdown.style.pointerEvents = 'none';
                }
            });

            // Checkbox logic
            checkboxes.forEach(cb => {
                cb.addEventListener('change', (e) => {
                    const val = cb.value;
                    if (cb.checked) {
                        activeFilters.push(val);
                        // Enforce max 2 limit (FIFO)
                        if (activeFilters.length > 2) {
                            const removed = activeFilters.shift(); // Remove the oldest
                            // Uncheck the oldest input
                            const oldCb = document.querySelector(`.filter-checkbox[value="${removed}"]`);
                            if(oldCb) oldCb.checked = false;
                        }
                    } else {
                        activeFilters = activeFilters.filter(f => f !== val);
                    }

                    // Apply filters (OR logic)
                    items.forEach(item => {
                        item.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                        
                        let shouldShow = true;
                        if (activeFilters.length > 0) {
                            shouldShow = activeFilters.some(filterClass => item.classList.contains(filterClass));
                        }

                        if (shouldShow) {
                            item.style.display = '';
                            setTimeout(() => { item.style.opacity = '1'; item.style.transform = 'scale(1)'; }, 20);
                        } else {
                            item.style.opacity = '0';
                            item.style.transform = 'scale(0.9)';
                            setTimeout(() => { item.style.display = 'none'; }, 300);
                        }
                    });
                    
                    // Trigger masonry layout update after animations
                    setTimeout(() => {
                        if (typeof Masonry !== 'undefined') {
                            const grid = document.querySelector('.gallery-grid');
                            const msnry = Masonry.data(grid);
                            if (msnry) msnry.layout();
                            else window.dispatchEvent(new Event('resize'));
                        } else {
                            window.dispatchEvent(new Event('resize'));
                        }
                    }, 310);
                });
            });
        });
        </script>
        <?php endif; ?>

        <div class="gallery-grid">
            <?php foreach ($gallery_items_data as $item): ?>
                <div class="<?php echo esc_attr($item['class']); ?>">
                    <a href="<?php echo esc_url($item['full']); ?>" class="glightbox" data-gallery="main-gallery">
                        <img src="<?php echo esc_url($item['thumb']); ?>" alt="<?php echo esc_attr($item['title']); ?>" loading="lazy" />
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        
        <?php if ($total_pages > 1): ?>
        <div style="margin-top: 4rem; text-align: center; display: flex; justify-content: center; gap: 1rem;">
            <?php 
            echo paginate_links(array(
                'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                'format' => '?paged=%#%',
                'current' => max(1, $paged),
                'total' => $total_pages,
                'prev_text' => '&laquo; Anterior',
                'next_text' => 'Siguiente &raquo;',
                'type' => 'list',
            ));
            ?>
        </div>
        <style>
            .page-numbers { display: inline-block; padding: 0.5rem 1rem; border: 1px solid var(--color-border); color: var(--color-text-primary); text-decoration: none; border-radius: 4px; transition: all 0.3s; }
            .page-numbers.current, .page-numbers:hover { background: var(--color-accent); color: #000; border-color: var(--color-accent); }
            ul.page-numbers { list-style: none; display: flex; gap: 0.5rem; padding: 0; margin: 0; }
        </style>
        <?php endif; ?>

    <?php else: ?>
        <div class="text-center" style="padding: 4rem 0;">
            <p class="text-body-lg">Aún no hay fotos en la galería.</p>
        </div>
    <?php endif; ?>
</div>



<?php get_footer(); ?>
