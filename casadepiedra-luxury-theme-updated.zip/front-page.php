<?php
/**
 * Template Name: Front Page
 * Description: Plantilla para la página de inicio.
 */
get_header(); 

// Obtener datos del hero centralizados del Panel Casa
$hero_subtitle = get_option('casa_opt_home_hero_subtitle', 'Desde 1845');
$hero_title = get_option('casa_opt_home_hero_title', 'El recinto más exclusivo <br /> de León.');
$hero_desc = get_option('casa_opt_home_hero_desc', 'Arquitectura de época, lujo contemporáneo y servicio impecable para bodas, convenciones y eventos que hacen historia.');
$hero_image = get_option('casa_opt_home_hero_img') ?: get_template_directory_uri() . '/assets/images/salon_principal_1779523069698.png';
?>

<section style="position: relative; min-height: 100vh; min-height: 100dvh; display: flex; align-items: center; overflow: hidden; padding-top: 5rem;">
    <div style="position: absolute; inset: 0; z-index: -1;">
        <img src="<?php echo esc_url($hero_image); ?>" alt="Casa de Piedra" class="img-cover gs-zoom-in" style="width: 100%; height: 100%; object-fit: cover; object-position: center; transform: scale(1.1); transition: transform 2.5s cubic-bezier(0.32, 0.72, 0, 1);" />
        <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(5,5,5,0.3) 0%, rgba(5,5,5,0.6) 60%, #050505 100%);"></div>
    </div>

    <div class="container" style="position: relative; z-index: 10;">
        <div style="max-width: 900px;">
            <div style="overflow: hidden; padding-top: 20px; margin-top: -20px;">
                <span class="text-script reveal-text" style="display: block; margin-bottom: 1rem; padding-top: 10px;">
                    <?php echo esc_html($hero_subtitle); ?>
                </span>
            </div>
            
            <div style="overflow: hidden;">
                <h1 class="text-hero reveal-text" style="margin-bottom: 1.5rem; text-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                    <?php echo wp_kses_post($hero_title); ?>
                </h1>
            </div>

            <div style="overflow: hidden;">
                <p class="text-body-lg reveal-text" style="color: rgba(255,255,255,0.8); margin-bottom: clamp(1.5rem, 5vh, 3.5rem); max-width: 600px;">
                    <?php echo esc_html($hero_desc); ?>
                </p>
            </div>

            <div style="overflow: hidden;">
                <div class="reveal-text" style="display: flex; flex-wrap: wrap; gap: 1.5rem; align-items: center;">
                    <a href="<?php echo esc_url(home_url('/espacios')); ?>" style="text-decoration: none; display: inline-flex; align-items: center; justify-content: center; background: var(--color-accent); color: #000; padding: 1rem 2.5rem; border-radius: 9999px; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                        Ver Espacios
                    </a>
                    <a href="<?php echo esc_url(home_url('/galeria')); ?>" style="color: var(--color-accent); text-decoration: none; font-family: var(--font-heading); font-size: 1.2rem; padding-bottom: 4px; border-bottom: 1px solid var(--color-border);">
                        Ver Galería
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Aquí Elementor puede inyectar el resto del contenido de la página de inicio -->
<?php if (trim(strip_tags(get_the_content()))) : ?>
<div class="elementor-content-area" style="padding: 4rem 0;">
    <div class="container">
        <?php the_content(); ?>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Zoom out animado de la imagen del hero
    setTimeout(() => {
        const img = document.querySelector('.gs-zoom-in');
        if(img) img.style.transform = 'scale(1)';
    }, 100);
});
</script>

<?php get_footer(); ?>
