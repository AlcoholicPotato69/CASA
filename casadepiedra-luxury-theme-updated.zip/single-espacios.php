<?php
/**
 * Template Name: Detalle de Espacio
 * Description: Plantilla para mostrar un espacio individual.
 */
get_header(); ?>

<main style="padding-top: 150px; padding-bottom: 7rem; min-height: 80vh;">
    <div class="container">
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <div class="grid md:grid-cols-12 gap-12">
                <div class="md:col-span-7 reveal-text">
                    <div style="border-radius: 1.5rem; overflow: hidden; height: 600px; position: relative;" class="gallery-container">
                        <style>
                        .espacio-slider {
                            position: relative;
                            width: 100%;
                            height: 100%;
                            overflow: hidden;
                            border-radius: 1.5rem;
                            background: #111;
                        }
                        .espacio-slider-track {
                            display: flex;
                            height: 100%;
                            transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
                        }
                        .espacio-slide {
                            position: relative;
                            cursor: zoom-in;
                            flex: 0 0 100%;
                            height: 100%;
                            display: block;
                        }
                        .espacio-slide img {
                            width: 100%;
                            height: 100%;
                            object-fit: cover;
                        }
                        .espacio-slider-dots {
                            position: absolute;
                            bottom: 25px;
                            left: 50%;
                            transform: translateX(-50%);
                            display: flex;
                            gap: 12px;
                            z-index: 10;
                            background: rgba(0,0,0,0.5);
                            padding: 8px 16px;
                            border-radius: 20px;
                            backdrop-filter: blur(4px);
                        }
                        .espacio-dot {
                            width: 10px;
                            height: 10px;
                            border-radius: 50%;
                            background: rgba(255,255,255,0.4);
                            border: none;
                            cursor: pointer;
                            transition: all 0.3s;
                            padding: 0;
                        }
                        .espacio-dot:hover {
                            background: rgba(255,255,255,0.9);
                        }
                        .espacio-dot.active {
                            background: var(--color-accent);
                            transform: scale(1.3);
                        }
                        </style>

                        <?php 
                        $gallery_ids = get_post_meta(get_the_ID(), '_casadepiedra_gallery_ids', true);
                        if (!empty($gallery_ids)) {
                            $ids_array = explode(',', $gallery_ids);
                            
                            echo '<div class="espacio-slider" id="espacioSlider">';
                            echo '<div class="espacio-slider-track" id="espacioSliderTrack">';
                            $index = 0;
                            foreach ($ids_array as $id) {
                                $img_url = wp_get_attachment_image_url($id, 'large');
                                $img_full = wp_get_attachment_image_url($id, 'full');
                                if ($img_url) {
                                    // Added glightbox class to open in integrated viewer
                                    echo '<a href="'.esc_url($img_full).'" class="espacio-slide glightbox" data-gallery="espacio-gallery">';
                                    echo '<img src="'.esc_url($img_url).'" alt="Galería Espacio" loading="lazy" />';
                                    echo '</a>';
                                    $index++;
                                }
                            }
                            echo '</div>';
                            
                            // Navigation Dots
                            if($index > 1) {
                                echo '<div class="espacio-slider-dots" id="espacioSliderDots">';
                                for ($i = 0; $i < $index; $i++) {
                                    $active = $i === 0 ? ' active' : '';
                                    echo '<button class="espacio-dot'.$active.'" data-index="'.$i.'" aria-label="Ir a la imagen '.($i+1).'"></button>';
                                }
                                echo '</div>';
                            }
                            
                            echo '</div>';
                        } else {
                            if(has_post_thumbnail()) { ?>
                                <a href="<?php the_post_thumbnail_url('full'); ?>" class="glightbox" data-gallery="espacio-gallery" style="display:block; height:100%; border-radius: 1.5rem; overflow: hidden;">
                                    <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover" style="cursor: zoom-in; width: 100%; height: 100%; object-fit: cover;" />
                                </a>
                            <?php } else { ?>
                                <div class="img-cover" style="background-color: var(--color-surface); height: 100%; border-radius: 1.5rem;"></div>
                            <?php } 
                        } ?>
                    </div>

                    <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const track = document.getElementById('espacioSliderTrack');
                        const dots = document.querySelectorAll('.espacio-dot');
                        if (!track || dots.length === 0) return;
                        
                        let currentIndex = 0;
                        const totalSlides = dots.length;
                        let autoPlayInterval;
                        
                        const goToSlide = (index) => {
                            if (index < 0) index = totalSlides - 1;
                            if (index >= totalSlides) index = 0;
                            currentIndex = index;
                            
                            track.style.transform = `translateX(-${currentIndex * 100}%)`;
                            
                            dots.forEach(dot => dot.classList.remove('active'));
                            dots[currentIndex].classList.add('active');
                        };
                        
                        const nextSlide = () => goToSlide(currentIndex + 1);
                        
                        const startAutoPlay = () => {
                            stopAutoPlay();
                            autoPlayInterval = setInterval(nextSlide, 3000);
                        };
                        
                        const stopAutoPlay = () => {
                            clearInterval(autoPlayInterval);
                        };
                        
                        dots.forEach((dot, index) => {
                            dot.addEventListener('click', (e) => {
                                e.preventDefault(); // Prevent accidental scroll
                                goToSlide(index);
                                startAutoPlay();
                            });
                        });
                        
                        const slider = document.getElementById('espacioSlider');
                        slider.addEventListener('mouseenter', stopAutoPlay);
                        slider.addEventListener('mouseleave', startAutoPlay);
                        
                        // Re-initialize GLightbox if necessary for dynamic content, though standard init should catch it
                        if(typeof GLightbox !== 'undefined') {
                            GLightbox({ selector: '.glightbox' });
                        }
                        
                        startAutoPlay();
                    });
                    </script>
                </div>
                
                <div class="md:col-span-5 reveal-text" style="display: flex; flex-direction: column; justify-content: center;">
                    <h1 class="text-h2" style="margin: 0 0 1.5rem 0; color: #fff;"><?php the_title(); ?></h1>
                    
                    <div class="text-body-lg" style="margin-bottom: 2.5rem;">
                        <?php the_content(); ?>
                    </div>
                    
                    <a href="<?php echo esc_url(home_url('/contacto')); ?>" style="align-self: flex-start; padding: 1rem 2.5rem; background: var(--color-accent); color: #000; border-radius: 9999px; text-decoration: none; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s; display: inline-block;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">Cotizar Espacio</a>
                </div>
            </div>
        <?php endwhile; endif; ?>
    </div>
</main>

<?php get_footer(); ?>
