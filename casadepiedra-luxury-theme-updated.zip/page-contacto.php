<?php
/**
 * Template Name: Contacto
 * Description: Plantilla para la página de contacto.
 */
get_header(); 

$portada_url = get_option('casa_opt_contacto_portada') ?: get_template_directory_uri() . '/assets/images/jardin_principal_1779523113451.png';
?>

<section style="position: relative; width: 100%; height: 50vh; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 4rem;">
    <img src="<?php echo esc_url($portada_url); ?>" alt="Contacto Portada" style="position: absolute; width: 100%; height: 100%; object-fit: cover; z-index: -1; filter: brightness(0.6);" class="gs-zoom-in" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(10,10,10,0.2) 0%, rgba(10,10,10,0.5) 70%, var(--color-bg, #0a0a0a) 100%); z-index: 0; pointer-events: none;"></div>
    <div style="position: relative; z-index: 1; text-align: center;">
        <span class="text-script reveal-text" style="font-size: 3.5rem; color: #fff;">Acércate</span>
        <h1 class="text-hero reveal-text" style="color: #fff; text-shadow: 0 10px 30px rgba(0,0,0,0.5); font-size: clamp(3rem, 6vw, 5rem);"><?php echo esc_html(get_option('casa_opt_contacto_title', 'Contacto')); ?></h1>
    </div>
</section>

<div style="padding-bottom: 6rem;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center; max-width: 700px; margin-left: auto; margin-right: auto;">
            <p class="text-body-lg" style="color: rgba(255,255,255,0.8); font-size: 1.2rem;">
                <?php echo esc_html(get_option('casa_opt_contacto_desc', 'Escribe tu historia aquí.')); ?>
            </p>
        </div>

        <div class="grid md:grid-cols-2 gap-12">
            <!-- Info -->
            <div class="reveal-text luxury-card" style="padding: 3rem;">
                <h3 class="text-h3" style="margin-bottom: 2rem; color: var(--color-accent);">Ponte en contacto</h3>
                
                <div style="margin-bottom: 2rem;">
                    <span class="text-caption">Horario de Oficina</span>
                    <p class="text-body-lg">Lunes a Viernes 8:30 hrs – 17:30 hrs.</p>
                </div>
                
                <div style="margin-bottom: 2rem;">
                    <span class="text-caption">Teléfono</span>
                    <p class="text-body-lg"><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', get_option('casa_opt_global_phone', '477 717 2600'))); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html(get_option('casa_opt_global_phone', '477 717 2600')); ?></a></p>
                </div>

                <div style="margin-bottom: 3rem;">
                    <span class="text-caption">Correo</span>
                    <p class="text-body-lg"><a href="mailto:<?php echo esc_attr(get_option('casa_opt_global_email', 'eventos@casadepiedraleon.mx')); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html(get_option('casa_opt_global_email', 'eventos@casadepiedraleon.mx')); ?></a></p>
                </div>

                <button type="button" id="open-quote-modal" style="display: inline-block; padding: 1rem 2.5rem; background: var(--color-accent); color: #000; border: none; cursor: pointer; border-radius: 9999px; text-decoration: none; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                    Solicitar Cotización
                </button>
                
                <!-- Opcional: Shortcode de Elementor o Contact Form 7 -->
                <div style="margin-top: 2rem;">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); the_content(); endwhile; endif; ?>
                </div>
            </div>

            <!-- Map -->
            <div class="reveal-text luxury-card" style="height: 400px;">
                <iframe 
                    src="<?php echo esc_url(get_option('casa_opt_contacto_map', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3662.6833868418894!2d-101.7002938!3d21.159507649999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842bbf53a2e4d0e3%3A0xfe1f47b7b2f6b0a3!2sCasa%20De%20Piedra!5e1!3m2!1ses-419!2smx!4v1779525259315!5m2!1ses-419!2smx')); ?>" 
                    width="100%" 
                    height="100%" 
                    style="border: 0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade"
                ></iframe>
            </div>
        </div>
    </div>
</div>

<!-- Quote Modal -->
<div id="quote-modal-overlay" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 9999; backdrop-filter: blur(5px); align-items: center; justify-content: center; padding: 1rem;">
    <style>
        .quote-grid { display: grid; grid-template-columns: 1fr; gap: 1rem; }
        @media (min-width: 640px) { .quote-grid { grid-template-columns: 1fr 1fr; } }
        .luxury-card-scroll::-webkit-scrollbar { width: 6px; }
        .luxury-card-scroll::-webkit-scrollbar-track { background: transparent; }
        .luxury-card-scroll::-webkit-scrollbar-thumb { background: rgba(212, 175, 55, 0.5); border-radius: 10px; }
        .luxury-card-scroll::-webkit-scrollbar-thumb:hover { background: rgba(212, 175, 55, 0.8); }
        .quote-select option { background-color: #1a1a1a; color: #ffffff; }
        .flatpickr-calendar { background: #1a1a1a !important; border: 1px solid rgba(255,255,255,0.1) !important; box-shadow: 0 10px 30px rgba(0,0,0,0.5) !important; }
        .flatpickr-day { color: #fff !important; }
        .flatpickr-day.selected, .flatpickr-day.startRange, .flatpickr-day.endRange, .flatpickr-day.selected.inRange, .flatpickr-day.startRange.inRange, .flatpickr-day.endRange.inRange, .flatpickr-day.selected:focus, .flatpickr-day.startRange:focus, .flatpickr-day.endRange:focus, .flatpickr-day.selected:hover, .flatpickr-day.startRange:hover, .flatpickr-day.endRange:hover, .flatpickr-day.selected.prevMonthDay, .flatpickr-day.startRange.prevMonthDay, .flatpickr-day.endRange.prevMonthDay, .flatpickr-day.selected.nextMonthDay, .flatpickr-day.startRange.nextMonthDay, .flatpickr-day.endRange.nextMonthDay { background: var(--color-accent) !important; border-color: var(--color-accent) !important; color: #000 !important; }
        .flatpickr-day.inRange { background: rgba(212, 175, 55, 0.2) !important; border-color: transparent !important; box-shadow: none !important; }
        .flatpickr-month, .flatpickr-weekday { color: #fff !important; fill: #fff !important; }
        .flatpickr-time input { color: #fff !important; }
        
        .iti { width: 100%; color: #000 !important; }
        .iti__country-list { background-color: #1a1a1a !important; color: #fff !important; border: 1px solid rgba(255,255,255,0.2) !important; border-radius: 8px !important; z-index: 99999 !important; text-align: left !important; }
        .iti__country.iti__highlight { background-color: rgba(255,255,255,0.1) !important; }
        .iti__divider { border-bottom: 1px solid rgba(255,255,255,0.1) !important; }
        .iti__dial-code { color: #aaa !important; }
        .iti__selected-dial-code { color: #fff !important; }
        .iti__country-name { color: #fff !important; }
    </style>
    
    <!-- Libraries CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/es.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

    <div class="luxury-card" style="position: relative; width: 100%; max-width: 600px; padding: 0; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; box-sizing: border-box;">
        <button id="close-quote-modal" style="position: absolute; top: 1rem; right: 1rem; background: rgba(0,0,0,0.5); border: none; color: #fff; font-size: 1.8rem; cursor: pointer; z-index: 10; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">&times;</button>
        
        <div class="luxury-card-scroll" style="padding: 3rem 2rem; overflow-y: auto; flex: 1; box-sizing: border-box; width: 100%;">
            <h3 class="text-h3" style="margin-bottom: 2rem; color: var(--color-accent); text-align: center; font-size: clamp(1.5rem, 4vw, 2rem);">Solicitar Cotización</h3>
        
        <form id="quote-form" style="display: flex; flex-direction: column; gap: 1.2rem;">
            <div class="quote-grid">
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Nombre Completo *</label>
                    <input type="text" name="quote_name" required style="width: 100%; padding: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Fecha de Evento *</label>
                    <input type="text" name="quote_date" id="quote_date" required placeholder="Selecciona fecha(s)" style="width: 100%; padding: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px; cursor: pointer;">
                </div>
            </div>
            <div class="quote-grid">
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Correo *</label>
                    <input type="email" name="quote_email" required style="width: 100%; padding: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Teléfono *</label>
                    <input type="tel" id="quote_phone" name="quote_phone" required style="width: 100%; padding-top: 0.8rem; padding-bottom: 0.8rem; padding-right: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px;">
                </div>
            </div>
            
            <div class="quote-grid">
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Salón (Espacio) *</label>
                    <select name="quote_salon" class="quote-select" required style="width: 100%; padding: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px; appearance: none;">
                        <option value="" disabled selected>Seleccione un salón</option>
                        <?php
                        $espacios = new WP_Query(array('post_type' => 'espacios', 'post_status' => 'publish', 'posts_per_page' => -1));
                        if($espacios->have_posts()) :
                            while($espacios->have_posts()) : $espacios->the_post();
                                echo '<option value="' . esc_attr(get_the_title()) . '">' . esc_html(get_the_title()) . '</option>';
                            endwhile;
                            wp_reset_postdata();
                        endif;
                        ?>
                    </select>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Tipo de Evento *</label>
                    <select name="quote_type" class="quote-select" required style="width: 100%; padding: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px; appearance: none;">
                        <option value="" disabled selected>Seleccione</option>
                        <option value="Festejos corporativos">Festejos corporativos</option>
                        <option value="Cumpleaños">Cumpleaños</option>
                        <option value="Bautizos/Bodas">Bautizos/Bodas</option>
                        <option value="Evento especial">Evento especial</option>
                    </select>
                </div>
            </div>
            
            <div>
                <label style="display: block; margin-bottom: 0.5rem; color: rgba(255,255,255,0.8); font-family: var(--font-body); font-size: 0.9rem;">Comentarios</label>
                <textarea name="quote_comments" rows="2" style="width: 100%; padding: 0.8rem; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px; resize: none;"></textarea>
            </div>

            <div style="font-size: 0.8rem; color: rgba(255,255,255,0.6); font-family: var(--font-body); text-align: center; margin-top: 0.5rem;">
                <em>* El seleccionar una fecha no garantiza una reservación de la misma, la fecha real del evento está sujeta a disponibilidad.</em>
            </div>
            
            <button type="submit" id="quote-submit-btn" style="width: 100%; padding: 1rem; background: var(--color-accent); color: #000; border: none; cursor: pointer; border-radius: 9999px; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s; margin-top: 0.5rem;">
                Enviar Solicitud
            </button>
            <div id="quote-form-msg" style="text-align: center; margin-top: 0.5rem; font-family: var(--font-body); display: none; font-size: 0.9rem;"></div>
        </form>

        <div id="quote-success-screen" style="display: none; text-align: center; padding: 2rem 0;">
            <div style="font-size: 4rem; color: #4ade80; margin-bottom: 1rem;">&#10003;</div>
            <h3 class="text-h3" style="color: var(--color-accent); margin-bottom: 1rem;">¡Solicitud Enviada!</h3>
            <p style="color: rgba(255,255,255,0.8); font-family: var(--font-body); margin-bottom: 2rem; line-height: 1.6;">Gracias por tu interés en Casa de Piedra.<br>Hemos enviado una confirmación a tu correo electrónico con los datos de tu evento. Pronto un asesor se pondrá en contacto contigo.</p>
            <button type="button" id="quote-close-success" style="padding: 1rem 2.5rem; background: var(--color-accent); color: #000; border: none; cursor: pointer; border-radius: 9999px; font-weight: 600; font-family: var(--font-body); transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                Cerrar
            </button>
        </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize flatpickr for dates (minDate is today to prevent past dates, range mode enabled)
    if (typeof flatpickr !== 'undefined') {
        flatpickr("#quote_date", {
            mode: "range",
            minDate: "today",
            dateFormat: "d-m-Y",
            locale: "es",
            disableMobile: "true"
        });
    }
    const btnOpen = document.getElementById('open-quote-modal');
    const btnClose = document.getElementById('close-quote-modal');
    const overlay = document.getElementById('quote-modal-overlay');
    const form = document.getElementById('quote-form');
    const msgDiv = document.getElementById('quote-form-msg');
    const submitBtn = document.getElementById('quote-submit-btn');
    const successScreen = document.getElementById('quote-success-screen');
    const btnCloseSuccess = document.getElementById('quote-close-success');

    // Init intl-tel-input
    const phoneInputField = document.querySelector("#quote_phone");
    let phoneInput = null;
    if(typeof window.intlTelInput !== 'undefined' && phoneInputField) {
        phoneInput = window.intlTelInput(phoneInputField, {
            preferredCountries: ["mx", "us", "es"],
            separateDialCode: true,
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
        });
    }

    const resetModal = () => {
        overlay.style.display = 'none';
        document.body.style.overflow = '';
        form.style.display = 'flex';
        successScreen.style.display = 'none';
        msgDiv.style.display = 'none';
        submitBtn.textContent = 'Enviar Solicitud';
        submitBtn.disabled = false;
        form.reset();
    };

    if(btnOpen && overlay) {
        btnOpen.addEventListener('click', () => {
            overlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        });
        
        btnClose.addEventListener('click', resetModal);
        
        if(btnCloseSuccess) {
            btnCloseSuccess.addEventListener('click', resetModal);
        }
        
        overlay.addEventListener('click', (e) => {
            if(e.target === overlay) {
                resetModal();
            }
        });
    }

    if(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if(phoneInput && !phoneInput.isValidNumber()) {
                msgDiv.style.display = 'block';
                msgDiv.style.color = '#f87171';
                msgDiv.textContent = 'Por favor, ingrese un número de teléfono válido.';
                return;
            }

            const formData = new FormData(form);
            formData.append('action', 'casa_send_cotizacion');
            
            if(phoneInput) {
                // Override with full formatted number
                formData.set('quote_phone', phoneInput.getNumber());
            }
            
            submitBtn.textContent = 'Enviando...';
            submitBtn.disabled = true;

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    form.style.display = 'none';
                    successScreen.style.display = 'block';
                } else {
                    msgDiv.style.display = 'block';
                    msgDiv.style.color = '#f87171';
                    msgDiv.textContent = data.data || 'Ocurrió un error. Inténtalo de nuevo.';
                    submitBtn.textContent = 'Enviar Solicitud';
                    submitBtn.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                msgDiv.style.display = 'block';
                msgDiv.style.color = '#f87171';
                msgDiv.textContent = 'Ocurrió un error de conexión.';
                submitBtn.textContent = 'Enviar Solicitud';
                submitBtn.disabled = false;
            });
        });
    }
});
</script>

<?php get_footer(); ?>
