<?php
/**
 * Template Name: Quiénes Somos
 * Description: Plantilla para la página de historia/nosotros.
 */
get_header(); 

$portada_url = get_option('casa_opt_nosotros_portada') ?: get_template_directory_uri() . '/assets/images/salon_principal_1779523069698.png';
?>

<section style="position: relative; width: 100%; height: 50vh; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 4rem;">
    <img src="<?php echo esc_url($portada_url); ?>" alt="Quiénes Somos Portada" style="position: absolute; width: 100%; height: 100%; object-fit: cover; z-index: -1; filter: brightness(0.6);" class="gs-zoom-in" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(10,10,10,0.2) 0%, rgba(10,10,10,0.5) 70%, var(--color-bg, #0a0a0a) 100%); z-index: 0; pointer-events: none;"></div>
    <div style="position: relative; z-index: 1; text-align: center;">
        <span class="text-script reveal-text" style="font-size: 3.5rem; color: #fff;">Nuestra Historia</span>
        <h1 class="text-hero reveal-text" style="color: #fff; text-shadow: 0 10px 30px rgba(0,0,0,0.5); font-size: clamp(3rem, 6vw, 5rem);">Quiénes Somos</h1>
    </div>
</section>

<div style="padding-bottom: 6rem;">
    <style>
        .bento-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        @media (min-width: 992px) {
            .bento-grid {
                grid-template-columns: 1.5fr 1fr;
            }
            .bento-tour {
                grid-column: 1 / -1;
            }
        }
    </style>

    <section class="section" style="padding-top: 4rem;">
        <div class="container">
            <div class="bento-grid">
                <!-- Texto Descriptivo Principal -->
                <div class="reveal-text luxury-card" style="padding: clamp(2rem, 5vw, 4rem); border-radius: 20px; display: flex; flex-direction: column; justify-content: center; background: rgba(255,255,255,0.02);">
                    <span class="text-script" style="font-size: clamp(2rem, 4vw, 3rem); display: block; color: var(--color-accent); margin-bottom: 0.5rem;">
                        <?php echo esc_html(get_option('casa_opt_nosotros_title', 'Nuestra Historia')); ?>
                    </span>
                    <h2 class="text-h2" style="margin-top: 0; font-size: clamp(1.5rem, 3vw, 2.2rem); margin-bottom: 2rem; line-height: 1.3;">
                        <?php echo esc_html(get_option('casa_opt_nosotros_subtitle', 'Testigo de grandeza y refinamiento a lo largo de los siglos.')); ?>
                    </h2>
                    
                    <div class="text-body-lg" style="line-height: 1.8; color: rgba(255,255,255,0.85); font-size: 1.05rem;">
                        <?php 
                        $nosotros_desc = get_option('casa_opt_nosotros_desc');
                        if (!empty($nosotros_desc)) {
                            echo wp_kses_post(stripslashes($nosotros_desc));
                        } else {
                            echo '<p style="margin-bottom: 1.5rem;">En el corazón de nuestra querida ciudad se erige la sublime ex hacienda, Casa de Piedra. Fundada en 1845, es famosa por su arquitectura y tradición incomparable.</p><p>Gracias a su más reciente remodelación, obra del reconocido arquitecto Jalisciense Roberto Elías, Casa de Piedra se ha transformado en un verdadero paraíso de exclusividad y elegancia.</p>';
                        }
                        ?>
                    </div>
                </div>

                <!-- Imagen Destacada Interactiva -->
                <div class="reveal-text luxury-card" style="padding: 0; border-radius: 20px; overflow: hidden; position: relative; min-height: 400px; display: flex;">
                    <?php 
                    $hero_img = get_option('casa_opt_nosotros_hero_img') ?: get_template_directory_uri() . '/assets/images/terraza_mezquite_1779523084857.png';
                    ?>
                    <a href="<?php echo esc_url(home_url('/galeria/')); ?>" style="display: block; width: 100%; height: 100%; position: absolute; inset: 0;" title="Ver Galería">
                        <img src="<?php echo esc_url($hero_img); ?>" alt="Casa de Piedra - Historia" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94);" class="gs-zoom-in" onmouseover="this.style.transform='scale(1.08)';" onmouseout="this.style.transform='scale(1)';" />
                        <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 40%); pointer-events: none;"></div>
                        <div style="position: absolute; bottom: 2rem; left: 2rem; pointer-events: none;">
                            <span style="color: #fff; font-family: var(--font-heading); font-size: 1.2rem; display: flex; align-items: center; gap: 0.5rem; letter-spacing: 1px; text-transform: uppercase;">Ver Galería <span style="color: var(--color-accent); font-size: 1.5rem;">&rarr;</span></span>
                        </div>
                    </a>
                </div>

                <!-- Recorrido Virtual -->
                <?php 
                $virtual_tour = get_option('casa_opt_nosotros_virtual_tour');
                if (empty(trim($virtual_tour))) {
                    $virtual_tour = 'https://publicmss.s3.amazonaws.com/Adivor/CasaDePiedra/V3/index.htm';
                }
                if (!empty($virtual_tour)) : 
                ?>
                <div class="reveal-text luxury-card bento-tour" style="height: 60vh; min-height: 450px; padding: 0; border-radius: 20px; overflow: hidden; display: flex; flex-direction: column;">
                    <div style="padding: 1.5rem 2rem; background: rgba(10,10,10,0.8); border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center;">
                        <h3 class="text-h3" style="margin: 0; font-size: 1.4rem; color: #fff;">Explora Casa de Piedra</h3>
                        <div style="width: 50px; height: 2px; background: var(--color-accent);"></div>
                    </div>
                    <iframe 
                        src="<?php echo esc_url($virtual_tour); ?>" 
                        width="100%" 
                        height="100%" 
                        style="border: 0; display: block; flex-grow: 1;" 
                        allowfullscreen="" 
                        loading="lazy" 
                    ></iframe>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>

<?php get_footer(); ?>
