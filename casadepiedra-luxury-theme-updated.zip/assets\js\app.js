document.addEventListener('DOMContentLoaded', () => {
    // 0. Initialize Lenis Smooth Scroll
    if (typeof Lenis !== 'undefined') {
        const lenis = new Lenis({
            duration: 1.2,
            easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            direction: 'vertical',
            gestureDirection: 'vertical',
            smooth: true,
            mouseMultiplier: 1,
            smoothTouch: false,
            touchMultiplier: 2,
        });

        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }

        requestAnimationFrame(raf);
    }

    // 0.5. Page Transition with Anime.js
    const overlay = document.getElementById('page-transition-overlay');
    if (overlay && typeof anime !== 'undefined') {
        // Entrance animation (Reveal page)
        anime({
            targets: overlay,
            translateY: ['0%', '-100%'],
            easing: 'easeInOutExpo',
            duration: 900,
            complete: function() {
                overlay.style.display = 'none';
                overlay.style.pointerEvents = 'none';
            }
        });

        // Exit animation (Hide page and redirect)
        document.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                const hasGlightbox = this.classList.contains('glightbox') || this.closest('.glightbox') !== null;
                const isImage = href.match(/\.(jpeg|jpg|gif|png|webp|svg|pdf)$/i) !== null;
                
                if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:') || this.getAttribute('target') === '_blank' || hasGlightbox || isImage) return;
                
                const isLocal = href.startsWith('/') || href.startsWith(window.location.origin);
                
                if (isLocal) {
                    e.preventDefault();
                    overlay.style.display = 'flex';
                    overlay.style.pointerEvents = 'auto'; // Block interaction while transitioning
                    
                    anime({
                        targets: overlay,
                        translateY: ['100%', '0%'],
                        easing: 'easeInOutExpo',
                        duration: 800,
                        complete: function() {
                            window.location.href = href;
                        }
                    });
                }
            });
        });

        // Fix for bfcache (Safari/Chrome back button) causing permanent black screen
        window.addEventListener('pageshow', function(event) {
            if (event.persisted) {
                overlay.style.display = 'none';
                overlay.style.pointerEvents = 'none';
                overlay.style.transform = 'translateY(-100%)';
                if(typeof anime !== 'undefined') anime.set(overlay, { translateY: '-100%' });
            }
        });
    }

    // 1. Navbar Scroll Effect (Manejo del fondo difuminado o sólido)
    const nav = document.querySelector('.header-wrapper');
    if (nav) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                nav.style.background = 'rgba(10, 10, 10, 0.95)';
                nav.style.borderBottom = '1px solid var(--color-accent)';
            } else {
                nav.style.background = 'rgba(10, 10, 10, 0.85)';
                nav.style.borderBottom = '1px solid var(--color-border-inner)';
            }
        });
    }

    // 2. Fullscreen Drawer Menu (Hamburger Menu)
    const hamburgerBtn = document.getElementById('nav-toggle');
    const fullscreenMenu = document.getElementById('fullscreen-menu');
    const menuLinks = fullscreenMenu ? fullscreenMenu.querySelectorAll('a') : [];
    let isMenuOpen = false;

    if (hamburgerBtn && fullscreenMenu) {
        hamburgerBtn.addEventListener('click', () => {
            isMenuOpen = !isMenuOpen;
            
            if (isMenuOpen) {
                hamburgerBtn.classList.add('is-active');
                gsap.to(fullscreenMenu, {
                    clipPath: 'circle(150% at calc(100% - 40px) 40px)',
                    duration: 1,
                    ease: 'power4.inOut'
                });
                if (menuLinks.length > 0) {
                    gsap.to(menuLinks, {
                        y: 0,
                        opacity: 1,
                        duration: 0.8,
                        stagger: 0.1,
                        delay: 0.3,
                        ease: 'power3.out'
                    });
                }
            } else {
                hamburgerBtn.classList.remove('is-active');
                gsap.to(fullscreenMenu, {
                    clipPath: 'circle(0% at calc(100% - 40px) 40px)',
                    duration: 0.8,
                    ease: 'power3.inOut'
                });
                if (menuLinks.length > 0) {
                    gsap.to(menuLinks, {
                        y: 50,
                        opacity: 0,
                        duration: 0.4,
                        ease: 'power2.in'
                    });
                }
            }
        });
    }

    // 3. GSAP Animations (Reveal Text)
    // Aparecen los elementos marcados con "reveal-text" a medida que entran en la pantalla
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        const revealElements = document.querySelectorAll('.reveal-text');
        
        revealElements.forEach((el) => {
            gsap.from(el, {
                scrollTrigger: {
                    trigger: el,
                    start: 'top 85%',
                },
                y: 50,
                opacity: 0,
                duration: 1,
                ease: 'power3.out'
            });
        });

        // Initialize GLightbox
        if (typeof GLightbox !== 'undefined') {
            const lightbox = GLightbox({
                selector: '.glightbox',
                touchNavigation: true,
                loop: true,
                zoomable: true
            });
        }
    }
});