<?php
/**
 * Template Name: Archivo de Restaurantes
 * Description: Plantilla para mostrar el grid de restaurantes.
 */
get_header(); 

$portada_url = get_option('casa_opt_restaurantes_portada') ?: get_template_directory_uri() . '/assets/images/terraza_mezquite_1779523084857.png';
?>

<section style="position: relative; width: 100%; height: 50vh; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 4rem;">
    <img src="<?php echo esc_url($portada_url); ?>" alt="Restaurantes Portada" style="position: absolute; width: 100%; height: 100%; object-fit: cover; z-index: -1; filter: brightness(0.6);" class="gs-zoom-in" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(10,10,10,0.2) 0%, rgba(10,10,10,0.5) 70%, var(--color-bg, #0a0a0a) 100%); z-index: 0; pointer-events: none;"></div>
    <div style="position: relative; z-index: 1; text-align: center;">
        <span class="text-script reveal-text" style="font-size: 3.5rem; color: #fff;">Gastronomía</span>
        <h1 class="text-hero reveal-text" style="color: #fff; text-shadow: 0 10px 30px rgba(0,0,0,0.5); font-size: clamp(3rem, 6vw, 5rem);"><?php echo esc_html(get_option('casa_opt_global_restaurantes_title', 'Nuestros Restaurantes')); ?></h1>
    </div>
</section>

<div style="padding-bottom: 6rem;">
    <div class="container">
        <div style="margin-bottom: 4rem; text-align: center; max-width: 700px; margin-left: auto; margin-right: auto;">
            <p class="text-body-lg" style="color: rgba(255,255,255,0.8); font-size: 1.2rem;">
                <?php echo esc_html(get_option('casa_opt_global_restaurantes_desc', 'Dentro del complejo Casa de Piedra, disfruta de propuestas gastronómicas exclusivas para deleitar tus sentidos.')); ?>
            </p>
        </div>

        <div class="grid md:grid-cols-2 gap-12">
            <?php
            $args = array(
                'post_type'      => 'restaurantes',
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'ASC'
            );
            $restaurantes_query = new WP_Query($args);

            if ($restaurantes_query->have_posts()) :
                while ($restaurantes_query->have_posts()) : $restaurantes_query->the_post(); 
                    $menu_url = get_post_meta(get_the_ID(), '_restaurante_menu', true);
                    $telefono = get_post_meta(get_the_ID(), '_restaurante_telefono', true);
                ?>
                    <div class="reveal-text">
                        <div class="luxury-card" style="height: 100%; display: flex; flex-direction: column;">
                            <a href="<?php the_permalink(); ?>" style="text-decoration: none; display: block;">
                                <div style="height: 450px; overflow: hidden; position: relative;">
                                    <?php if (has_post_thumbnail()) : ?>
                                        <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title_attribute(); ?>" class="img-cover hover:scale-105 transition-transform duration-700" style="transition: transform 0.7s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';" />
                                    <?php else : ?>
                                        <div class="img-cover" style="background-color: var(--color-surface);"></div>
                                    <?php endif; ?>
                                </div>
                            </a>
                            <div style="padding: 1.5rem; display: flex; flex-direction: column;">
                                <span class="text-caption" style="font-size: 0.75rem;">Especialidad</span>
                                <h3 class="text-h3" style="color: var(--color-text-primary); margin-top: 0.2rem; margin-bottom: 1rem; font-size: 1.8rem; display: flex; align-items: center; gap: 15px;">
                                    <?php 
                                    $logo_url = get_post_meta(get_the_ID(), '_restaurante_logo', true);
                                    if ($logo_url) : 
                                    ?>
                                        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php the_title_attribute(); ?> Logo" style="height: 45px; width: auto; object-fit: contain;" />
                                    <?php endif; ?>
                                    <a href="<?php the_permalink(); ?>" style="text-decoration: none; color: inherit;"><?php the_title(); ?></a>
                                </h3>
                                
                                <div style="display: flex; gap: 0.8rem; flex-wrap: wrap; align-items: center; border-top: 1px solid var(--color-border-inner); padding-top: 1rem;">
                                    
                                    <?php if ($menu_url) : ?>
                                        <a href="<?php echo esc_url($menu_url); ?>" target="_blank" style="color: #fff; background: var(--color-surface); border: 1px solid var(--color-border); padding: 0.5rem 1rem; border-radius: 4px; font-size: 0.9rem; text-decoration: none; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)';" onmouseout="this.style.background='var(--color-surface)';">
                                            Ver Menú
                                        </a>
                                    <?php endif; ?>
                                    
                                    <a href="<?php echo casadepiedra_get_reserva_url(get_the_ID()); ?>" style="color: #000; background: var(--color-accent); padding: 0.5rem 1rem; border-radius: 4px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.05)';" onmouseout="this.style.transform='scale(1)';">
                                        Reservar
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile;
                wp_reset_postdata();
            else : ?>
                <p style="text-align: center; grid-column: 1 / -1; color: var(--color-text-secondary);">Próximamente nuevos restaurantes.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>
